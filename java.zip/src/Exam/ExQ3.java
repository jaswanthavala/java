package Exam;

public class ExQ3 {

	public static void main(String[] args) {
		int sum=1;
		int n=5;
		for (int i=1;i<=n;i++) {
			for (int j=1;j<=i;j++) {
				System.out.print(sum +" ");
				sum++;
			}
			System.out.println();
		}

	}

}
