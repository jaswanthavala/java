package Exam;

import java.util.Scanner;

import java.util.Scanner;

public class SumOfprefectNumbers {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int n = s.nextInt();
        s.close();  // Close the scanner once input is taken
        int sum1=0;
        for (int i = 1; i <= n; i++) {
            int sum = 0;
            for (int j = 1; j < i; j++) {  // Exclude the number itself (j != i)
                if (i % j == 0) {
                    sum += j;
                }
            }
            if (sum == i) {
            sum1 = sum1+i;
                System.out.println(sum1);  // It's a perfect number
            }
        }
    }
}
