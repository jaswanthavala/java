package Exam;
interface A{
	void run();
}
abstract class B implements A{
 public   abstract	void run();
}
public class Interface extends B {
	public void run() {
		System.out.println("interface class is running");
	}
public static void main(String[] args) {
	A i = new Interface();
	i.run();
}
}
