package Exam;
import java.util.Scanner;
public class ExQ4 {
public static void main(String[] args) {
	Scanner s = new Scanner (System.in);
	System.out.println("enter a number :");
	int n=s.nextInt();
	s.close();
	double tot=0;
	for(int i=1;i<=n;i++) {
		double sum=0;
		int  fact =1;
		for (int j=i;j>=i;j--) {
			fact =fact*j;
		}
		sum=1/(Math.pow(i, fact));
		tot =tot+sum;
		
		
	}
	System.out.println(tot);
}
}
