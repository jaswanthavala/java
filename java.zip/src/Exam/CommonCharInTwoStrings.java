package Exam;

import java.util.Scanner;

public class CommonCharInTwoStrings {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	String s1= s.nextLine();
	String s2 = s.nextLine();
	String s3="";
		for(int i=0;i<=s1.length()-1;i++) {

			for(int j = 0; j<=s2.length()-1;j++) {
			
			if(s1.charAt(i) == s2.charAt(j)) {
				
			s3 = s3+s1.charAt(i);
			
			}
			
			s.close();
	}
	}	
		System.out.println(s3);
}
}
