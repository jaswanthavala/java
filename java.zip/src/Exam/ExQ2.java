package Exam;

public class ExQ2 {

	public static void main(String[] args) {
		int arr[]= {6,34,28,496,55};
		for(int i=0;i<arr.length;i++) {
			int sum=0;
			for(int j=1;j<arr[i];j++) {
				if(arr[i]%j==0) {
					sum =sum+j;
				}
				
			}
			if(sum==arr[i]) {
				System.out.println(arr [i] +" prefect number");
			}
		}

	}

}
