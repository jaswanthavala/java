package Exam;
class demo extends Exception{
	public demo(String s) {
		super(s);
	}
}
public class UserDefine {
public static void main(String[] args) {
	try {
		int i=50;
		if(i>40) {
			throw new demo("exception occured");
			
		}
		else {
			System.out.println("i is with in the class");
		}
	}
	catch(demo d) {
		System.out.println(d);
		d.printStackTrace();
		
	}
}
}
