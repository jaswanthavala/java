package Maps;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapEx1 {
public static void main(String[] args) {
	LinkedHashMap<Integer , String> h = new LinkedHashMap<Integer,String>();
	h.put(1, "virat");
	h.put(2, null);
	h.put(3, "kohli");
	for(Map.Entry e :h.entrySet()) {
		System.out.println(e.getKey()+" "+e.getValue());
	}
}
}
