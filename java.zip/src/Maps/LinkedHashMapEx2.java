package Maps;

import java.util.LinkedHashMap;
import java.util.Map;

class linked
{
	int id ;
	String name;
	int salary;
	linked(int id ,String name,int salary){
	this.id = id;
	this.name=name;
	this.salary= salary;
	}
}
public class LinkedHashMapEx2 {
public static void main(String[] args) {
	LinkedHashMap<Integer,linked> e = new LinkedHashMap<Integer, linked>();
	linked l1 = new linked(1,"mani",2343535);
	linked l2 = new linked(23,"hemu",345323);
	linked l3 = new linked(3,"hemanth",325323);
	e.put(1, l1);
	e.put(2, l2);
	e.put(3,l3);
	for(Map.Entry<Integer, linked>m: e.entrySet()) {
		int i = m.getKey();
		linked k = m.getValue();
		System.out.println(i+"key = "+k.id+" "+k.name+" "+k.salary);
	}
	
}
}
