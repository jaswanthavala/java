package Maps;

import java.util.HashMap;
import java.util.Map;

class hash{
	int id ;
	String name;
	String sector;
	hash(int id , String name,String sector){
		this.id = id;
		this.name= name;
		this.sector= sector;
	}
}
public class HashMapEx3 {
public static void main(String[] args) {
	HashMap<Integer,hash> h = new HashMap<Integer , hash>();
	hash h1 = new hash(21, "mani","sales");
	hash h2 = new hash(33,"sai","b2b");
	hash h3 = new hash(44,"raj","sales");
	h.put(1,h1);
	h.put(2, h2);
	h.put(3, h3);
	 for(Map.Entry<Integer, hash> m :h.entrySet()) {
		 int k =m.getKey();
		 hash  l= m.getValue();
		 System.out.println(k +" key");
		 System.out.println(l.id+" "+l.name+" "+l.sector);
	 }
}
}
