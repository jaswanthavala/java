package Maps;

import java.util.HashMap;
import java.util.Map;

public class HashMapEx2 {
public static void main(String[] args) {
	HashMap<Integer, String> h = new HashMap<Integer , String>();
	h.put(23,"virat");
	h.put(null, null);
	h.put(34,"sachin");
	HashMap<Integer, String> h1 = new HashMap<Integer , String>();
	h1.put(null, null);
	h1.put(33, null);
	h1.putAll(h);
	
	for(Map.Entry e :h1.entrySet() ) {
		System.out.println(e.getKey()+"="+e.getValue());
	//	System.out.println(h1.clone());
		//System.out.println(h1.containsKey(33));
	}
	System.out.println(h1.clone());
	System.out.println(h1.containsKey(33));
	h1.remove(33);
	System.out.println(h1);
}
}
