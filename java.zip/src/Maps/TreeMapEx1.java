package Maps;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
public class TreeMapEx1 {
public static void main(String[] args) {
	TreeMap<Integer, String> t = new TreeMap<Integer, String>();
	t.put(1, "jaswanth");
	t.put(2, null);
	t.put(3, "avala");
	for(Map.Entry<Integer, String> e : t.entrySet()) {
		System.out.println(e.getKey()+" "+e.getValue());
	}

}
}
