package Maps;

import java.util.Hashtable;
import java.util.Map;

public class HashTableEx1 {

	public static void main(String[] args) {
		Hashtable<Integer, String > h = new Hashtable<Integer, String>();
h.put(1, "jassu");
h.put(2, "jaswanth");
h.put(3, "balaji");
for(Map.Entry<Integer, String> e : h.entrySet()) {
	System.out.println(e.getKey());
	System.out.println(e.getValue());
}
h.remove(3);
System.out.println(h);
	}

}
