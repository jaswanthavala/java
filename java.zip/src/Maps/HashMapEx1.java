package Maps;

import java.util.HashMap;
import java.util.Map;

public class HashMapEx1 {

	public static void main(String[] args) {
		HashMap<Integer, String> h = new HashMap();
		h.put(1,"chandu");
		h.put(2, "jnanu");
		h.put(3,"jaswanth");
		for(Map.Entry m : h.entrySet()) {
			System.out.println(m.getKey()+" "+m.getValue());
		}

	}

}
