package Maps;

import java.util.Map;
import java.util.TreeMap;

class book{
	int id;
	String name;
	int Class;
	int quantity;
	book(int id , String name, int Class, int quantity){
		this.id= id;
		this.name= name;
		this.Class= Class;
		this.quantity= quantity;
	}
}
public class TreeMapEx2 {
public static void main(String[] args) {
	TreeMap<Integer, book> t = new TreeMap<Integer , book>();
	book b1 = new book(1,"maths ",7 ,100);
	book b2 = new book(4,"english",8 ,100);
	book b3 = new book(3,"hindi",9 ,100);
	t.put(1,b1);
	t.put(3, b2);
	t.put(2, b3);
	for(Map.Entry<Integer, book> e : t.entrySet()) {
		int i = e.getKey();
		book k = e.getValue();
		System.out.println(i+" key = "+" "+k.id+" "+k.name+" "+k.Class+" "+k.quantity);
	}
}
}
