package ChatGPtOOPS;
class preson{
	String name;
	int age;
	public preson(String name, int age) {
		this.name=name;
		this.age=age;
	}
	public void display() {
		System.out.println(name);
		System.out.println(age);
	}
}
class employeee extends preson{
	double salary;
	public employeee( String name, int age,double salary) {
		super(name,age);
		this.salary=salary;
	}
	public void displayemployee() {
		display();
		System.out.println(salary);
	}
}
public class example4inheritance {
public static void main(String[] args) {
	employeee e = new employeee("jaswanth",22,23423.3);
	e.displayemployee();
}
}
