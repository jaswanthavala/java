package ChatGPtOOPS;
abstract class Animall{
	abstract void makeSound();
}
	class cat extends Animall{
	 void makeSound() {
		 System.out.println("cat making sounds");
	 }
 }
	class dog1 extends Animall{
		void makeSound() {
			System.out.println("dog making sounds");
		}
	}
public class AbstractExample1 {
public static void main(String[] args) {
	Animall a = new cat();
	a.makeSound();
}
}
