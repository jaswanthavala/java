package ChatGPtOOPS;

class BankAccount{
	private String  accountNumber;
	private double  balance;
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber( String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
}

public class EncapsulationExample1 {
public static void main(String[] args) {
	BankAccount b = new BankAccount();
	b .setAccountNumber("42342687624");
	b.setBalance(4317834.454);
	System.out.println(b.getAccountNumber());
	System.out.println(b.getBalance());
}
}
