package ChatGPtOOPS;
class Animal{
	void eat() {
		System.out.println("eating");
	}
}
class dog extends Animal{
	void bark()
	{
		System.out.println("barking");
	}
}
class puppy extends dog{
	void play() {
		System.out.println("playing");
	}
}
public class Example2 {
public static void main(String[] args) {
	puppy p = new puppy();
	p.bark();
	p.eat();
	p.play();
}
}
