package ChatGPtOOPS;
class vehiclemode{
	void move() {
		System.out.println("The vehicle is moving");
	}
}
class car1 extends vehiclemode{
	void move() {
		System.out.println("The car is moving..");
	}
}
public class polyExample2 {
public static void main(String[] args) {
	vehiclemode c = new car1();
	c.move();
	c= new vehiclemode();
	c.move();
}
}
