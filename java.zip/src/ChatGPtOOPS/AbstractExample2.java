package ChatGPtOOPS;
interface vehicle{
	abstract void stop();
	abstract void start();
	
}
class car implements vehicle{
	public void stop() {
		System.out.println("stop the car");
	}
	public void start() {
		System.out.println("start the car");
	}
}
class bike implements vehicle{
	public void stop()
	{
		System.out.println("stop the bike");
	}
	public void start() {
		System.out.println("start the bike");
	}
}
public class AbstractExample2 {
public static void main(String[] args) {
	vehicle c = new bike();
	c.start();
	c.stop();
}
}
