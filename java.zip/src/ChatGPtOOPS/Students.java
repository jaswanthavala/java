package ChatGPtOOPS;
class Student{
	String name;
	int rollNo;
	public  Student(String name, int rollNo) {
		this.name=name;
		this.rollNo=rollNo;
	}
	public void showDetails() {
		System.out.println(name );
		System.out.println(rollNo);
	}
}
public class Students {
public static void main(String[] args) {
	Student s = new Student("jaswanth",1223);
	Student s1= new Student("chandu",1234);
	s.showDetails();
	s1.showDetails();
}
}
