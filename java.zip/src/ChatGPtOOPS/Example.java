package ChatGPtOOPS;
class person{
	String name ;
	int age;
	public person(String name ,int age) {
		this.name=name;
		this.age=age;
	}
	public void display() {
		System.out.println(name);
		System.out.println(age);
	}
}
class employe extends person{
	int salary;
	public employe(String name, int age,int salary) {
		super(name, age);
		this.salary=salary;
	}
public void displayemploye()
{
	display();
	System.out.println(salary);
}
	
}
public class Example {
public static void main(String[] args) {
	employe e = new employe("jaswanth",22,30000);
	e.displayemploye();
}
}
