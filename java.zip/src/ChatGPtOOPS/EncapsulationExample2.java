package ChatGPtOOPS;
class Book{
	 private String title;
	private String author;
	private int price;
	
	public String getTitle() {
		return title;
	
	}
	public void setTitle(String title) {
		this.title= title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
}
public class EncapsulationExample2 {
public static void main(String[] args) {
Book b = new Book();
b.setAuthor("American");
b.setTitle("Times of india");
b.setPrice(150);
System.out.println(b.getTitle()+" "+ b.getAuthor()+" "+b.getPrice());

}
}
