package ChatGPtOOPS;
 class Car{
	String brand;
	String model;
	int year;
	 
	public Car(String brand,String model,int year) {
		this.brand =brand;
		this.model= model;
		this.year=year;
	}


 public  void displayInfo() {
	 System.out.println(brand);
		System.out.println(model);
		System.out.println(year);
 }
 }
public class ClassAndObject {

public static void main(String[] args) {
	Car c = new Car("maruthi","swift",2018);

	c.displayInfo();
}
}
