package ChatGPtOOPS;
class Shape{
	void Draw() {
		System.out.println("drawing");
	}
}
class circle extends Shape{
	void Draw()
	{
		System.out.println("draw a circle ");
	}
}
class rectangle extends Shape{
	void Draw() {
		System.out.println("draw a rectangle");
	}
}
public class PolyExample1 {
public static void main(String[] args) {
	Shape s = new circle();
	s.Draw();
	s= new rectangle();
	s.Draw();
}
}
