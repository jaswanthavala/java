package ChatGPtOOPS;
class calculator{
	void add(int a ,int b) {
		System.out.println(a+b);
	}
	void add(int a ,int b ,int c) {
		System.out.println(a+b+c);
	}
}
public class PolyExample2 {
public static void main(String[] args) {
	calculator c = new calculator();
	c.add(34243, 03431);
	c.add(423443, 32445, 4242);
}
}
