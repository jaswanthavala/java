package ChatGPtOOPS;
interface Flyable{
	abstract void fly();
}
interface Swimmable{
	abstract void swim();
}
class Duck implements Flyable,Swimmable{
	public void fly()
	{
		System.out.println("bird is flying");
	}
	public void swim() {
		System.out.println("bird is swimming");
}
}
public class MultipleInheritance {
public static void main(String[] args) {
	Duck d = new Duck();
	d.fly();
	d.swim();

	
}
}
