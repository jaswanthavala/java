package MapInTERface;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapLinkedHashMap {
public static void main(String[] args) {
	LinkedHashMap<Integer,String>l = new LinkedHashMap<>();
	l.put(1, null);
	l.put(2, null);
	l.put(3, "jaswanth");
	LinkedHashMap<Integer,String>lh = new LinkedHashMap<>();
	lh.put(2, "chandu");
	lh.put(4,"sri");
	l.putAll(lh);
	for(Map.Entry e : l.entrySet()) {
		System.out.println(e.getKey()+"  "+e.getValue());
	}
}
}
