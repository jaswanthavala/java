package MapInTERface;

import java.util.LinkedHashMap;
import java.util.Map;

class hash{
	int id ;
	String name;
	String phone;
	hash(int id ,String name,String phone){
		this.id=id;
		this.name=name;
		this.phone= phone;
	}
}
public class LinkedHashMapOnObjects {
public static void main(String[] args) {
	hash h = new hash(1,"jaswanth","2343546453");
	hash h1 = new hash(2,"avala","324242435");
	hash h2 = new hash(3,"chandu","4354354624");
	LinkedHashMap<Integer , hash>l = new LinkedHashMap<Integer ,hash>();
	l.put(1, h);
	l.put(2, h1);
	l.put(3, h2);
	hash h3 = new hash(1,"jassu","2343546453");
	hash h4 = new hash(2,"avala","324242435");
	LinkedHashMap<Integer , hash>ll = new LinkedHashMap<Integer ,hash>();
	ll.put(4, h3);
	ll.put(5, h4);
	l.putAll(ll);
	for(Map.Entry<Integer,hash> e :l.entrySet()) {
		int k = e.getKey();
		hash m =e.getValue();
		System.out.println(m.id+" "+m.name+" "+m.phone);
	}
	
}
}
