package MapInTERface;

import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
class tree{
	int id;
	String name;
	int salary;
	public int phone;
	tree(int id ,String name,int salary){
		this.id =id;
		this.name= name;
		this.salary=salary;		
	}
}
public class TreeMapOnObject {
public static void main(String[] args) {
	tree t = new tree(1,"jaswanth ",424445);
	tree t1 = new tree(1234," avala jaswanth ",42444532);
	tree t2= new tree(1565,"jaswanth avala ",424434);
	tree t3 = new tree(11213,"avala ",42434345);
	TreeMap<Integer,tree >tm = new TreeMap<>();
	tm.put(1,t);
	tm.put(2323, t1);
	tm.put(232, t2);
	tm.put(21, t3);
	tree t4 = new tree(19,"vijay ",42446445);
	tree t5= new tree(232,"jassu ",42444235);
	tree t6= new tree(342,"arjun ",424467545);
	tree t7= new tree(121,"jaswanth ",424448905);
	TreeMap<Integer,tree >ts = new TreeMap<>();
	ts.put(23, t4);
	ts.put(34, t5);
	ts.put(234, t6);
	ts.put(435, t7);
	tm.putAll(ts);
	for(Map.Entry <Integer,tree>e :tm.entrySet())
	{
	int k = e.getKey();
	tree r = e.getValue();
	System.out.println(k +" details");
	System.out.println(r.id+" "+r.name+" "+r.salary);
	}
}
}
