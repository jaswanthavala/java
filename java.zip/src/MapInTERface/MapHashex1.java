package MapInTERface;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class MapHashex1 {
public static void main(String[] args) {
	HashMap<Integer,String> h = new HashMap<>();
	h.put(1, "jaswamth");
	h.put(2, null);
	h.put(3, null);
	h.put(null,null);
	for(Map.Entry e :h.entrySet()) {
		System.out.println(e.getKey()+"  "+e.getValue());
	}
}
}
