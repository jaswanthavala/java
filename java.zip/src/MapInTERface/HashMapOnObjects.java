package MapInTERface;

import java.util.HashMap;
import java.util.Map;

class mapps{
	int id ;
	String name;
	int salary;
	mapps(int id,String name ,int salary){
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
}
public class HashMapOnObjects {
public static void main(String[] args) {
	mapps m = new mapps(1,"jaswanth  ",132213);
	mapps m1 = new mapps(2,"avala  ",13123);
	HashMap<Integer,mapps>h = new HashMap<>();
	h.put(1,m);
	h.put(2, m1);
	for(Map.Entry<Integer,mapps> e :h.entrySet()) {
	int k = e.getKey();
	mapps s = e.getValue();
	System.out.println(s.id+" "+s.name+s.salary);
	}
}
}
