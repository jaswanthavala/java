package MapInTERface;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapex1 {
public static void main(String[] args) {
	TreeMap<Integer,String >t = new TreeMap<>();
	t.put(1, null);
	t.put(2, "jaswanth");
	t.put(355, "avala");
	TreeMap<Integer,String >tm= new TreeMap<>();
	tm.put(4,"chandu");
	tm.put(5, null);
	t.putAll(tm);
	for(Map.Entry e :t.entrySet()) {
		System.out.println(e.getKey()+" "+e.getValue());
	}
}
}
