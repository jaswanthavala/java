package MapInTERface;

import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;
class table{
	int id ;
	String name;
	String phonenumber;
	table(int id,String name,String phonenumber){
		 this.id=id;
		 this.name=name;
		 this.phonenumber=phonenumber;
	}
}
public class HashTableOnObject {
public static void main(String[] args) {
	table t = new table(1,"vijay","424232423");
	table t1 = new table(2,"kerthi","4325231434");
	table t3 = new table(3,"jassu","23424352123");
	Hashtable<Integer,table> h = new Hashtable<Integer,table>();
	h.put(1, t);
	h.put(5, t1);
	h.put(2, t3);
	table t2 = new table(11,"vijay","4534232423");
	table t4 = new table(23,"HEMANTH","2312121434");
	table t5 = new table(323,"jaswANTH","23424343123");
	Hashtable<Integer,table> ht = new Hashtable<Integer,table>();
	ht.put(232, t2);
	ht.put(3, t4);
	ht.put(4,t5);
	h.putAll(ht);
	for(Map.Entry<Integer, table> e :h.entrySet()) {
		int k = e.getKey();
		table m = e.getValue();
		System.out.println(k +" details");
		System.out.println(m.id+" "+m.name+" "+m.phonenumber);
	}
}
}
