package MapInTERface;

import java.util.Hashtable;
import java.util.Map;

public class HashTableEX1 {
public static void main(String[] args) {
	Hashtable<Integer,String> h = new Hashtable<Integer, String>();
	h.put(1, "jaswanth");
	h.put(232, "drive");
	h.put(3, "avala");
	Hashtable<Integer,String> ht = new Hashtable<Integer, String>();
	ht.put(4, "arjun");
	ht.put(32243, "avala jaswanth");
	h.putAll(ht);
	System.out.println(h);
	for(Map.Entry<Integer,String> e:h.entrySet()) {
		System.out.println(e.getKey()+" "+e.getValue());
	}
}
}
