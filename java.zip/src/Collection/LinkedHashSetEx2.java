package Collection;

import java.util.Iterator;
import java.util.LinkedHashSet;

class laptop{
	int id ;
	String companyname;
	int price;
	laptop(int id ,String companyname,int price){
		this.id= id;
		this.companyname= companyname;
		this.price= price;
	}
}
public class LinkedHashSetEx2 {
public static void main(String[] args) {
	LinkedHashSet<laptop> l = new LinkedHashSet<laptop>();
	laptop l1 = new laptop(1, "lenovo",56000);
	laptop l2 = new laptop(2,"dell",60000);
	laptop l3 = new laptop(3, "hp",56000);
	l.add(l1);
	l.add(l2);
	l.add(l3);
	Iterator i = l.iterator();
	while(i.hasNext()) {
		laptop l4= (laptop) i.next();
		System.out.println(l4.id+" "+l4.companyname+" "+l4.price);
	}
}
}
