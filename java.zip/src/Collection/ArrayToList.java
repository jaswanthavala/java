package Collection;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrayToList {
	public static void main(String[] args) {
		String [] arr = {"rwer","etea","rtgert"};
		System.out.println(Arrays.toString(arr));
		ArrayList <String>l = new ArrayList<String>();
		for(String s:l) {
			l.add(s);
			System.out.println(l);
		}
	}

}
