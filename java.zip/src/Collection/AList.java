package Collection;

import java.util.ArrayList;
import java.util.Iterator;
class Studen{
	int rollno;
	String name;
	 Studen(int rollno, String name) {
		this.rollno=rollno;
		this.name= name;
	}
}
public class AList {
	public static void main(String[] args) {
		Studen s = new Studen(101,"JASSU");
		Studen s1 =new Studen(102,"chandu");
		ArrayList al = new ArrayList();
		al.add(s);
		al.add(s1);
		Iterator i = al.iterator();
		while(i.hasNext()) {
			Studen s2 = (Studen) i.next();
			System.out.println(s2.rollno+" "+s2.name);
		}
		
	}

}
