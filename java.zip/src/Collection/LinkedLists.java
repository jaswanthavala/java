package Collection;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedLists {
public static void main(String[] args) {
	LinkedList <String> l = new LinkedList<>();
	l.add("jaswanth");
	l.add("chandu");
	l.add("nuthana");
	l.add("jnanviki sri");
	Iterator<String>  i = l.descendingIterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
}
}
