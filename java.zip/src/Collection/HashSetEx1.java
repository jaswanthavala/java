package Collection;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetEx1 {
	public static void main(String[] args) {
		HashSet <String> s = new HashSet<String>();
		s.add("jaswanth");
		s.add("arjun");
		s.add("naresh");
		Iterator i = s.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
	}

}
