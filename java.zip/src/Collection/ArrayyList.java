package Collection;

import java.util.ArrayList;
import java.util.Iterator;

class Student{
	int id ;
	String name;
	Student(int id ,String name)
	{
		this.id=id;
		this.name=name;
	}
}
public class ArrayyList {
public static void main(String[] args) {
	Student s = new Student(24,"jaswanth");
	Student s1= new Student(34,"avala");
	Student s3=new Student(24,"jassu");
	ArrayList<Student> al = new ArrayList<Student>();
	al.add(s);
	al.add(s1);
	al.add(s3);
	Iterator<Student> i=al.iterator(); 
	while(i.hasNext()) {
		Student s2 = (Student) i.next();
		System.out.println(s2.id+" "+s2.name);
	}
}
}
