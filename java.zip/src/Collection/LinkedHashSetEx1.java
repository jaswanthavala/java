package Collection;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetEx1 {
public static void main(String[] args) {
		LinkedHashSet <String> l = new LinkedHashSet <String>();
		l.add("chandu");
		l.add("jnanu");
		l.add("nuthana");
		Iterator i =l.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
}
}
