package Collection;

import java.util.ArrayList;
import java.util.Iterator;

public class arrays {
public static void main(String[] args) {
	ArrayList<String> al = new ArrayList<String>();
	al.add("avala");
	al.add("jaswanth");
	al.add("jassu");
	Iterator<String> i =al.iterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
}
}
