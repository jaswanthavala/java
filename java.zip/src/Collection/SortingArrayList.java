package Collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortingArrayList {
public static void main(String[] args) {
	ArrayList<String> al = new ArrayList<String>();
	al.add("mango");
	al.add("apple");
	al.add("kiwi");
	Collections.sort(al);
	for(String s:al) {
		System.out.println(s);
	}
	List<Integer> l = new ArrayList<Integer>();
	l.add(1);
	l.add(2);
	l.add(3);
	Collections.sort(l);
	for(Integer i:l) {
		System.out.println(l);
	}
}
}
