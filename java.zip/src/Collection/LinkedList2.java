package Collection;

import java.util.Iterator;
import java.util.LinkedList;

class Empolyee{
	int id;
String name;
int salary;
Empolyee(int id ,String name ,int salary){
	this.id= id;
	this.name= name;
	this.salary= salary;
}
}
public class LinkedList2 {
public static void main(String[] args) {
	Empolyee e1 = new Empolyee(201,"nuthana",50000);
	Empolyee e2 = new Empolyee(202,"sri",55000);
	Empolyee e3 = new Empolyee(202,"heamanth",40000);
	LinkedList l = new LinkedList();
	l.add(e1);
	l.add(e2);
	l.add(e3);
	Empolyee e5 = new Empolyee(206,"jassu",50000);
	LinkedList l1 =new 	LinkedList();
l1.add(e5);
	l.addAll(l1);
	
	Iterator i =l.iterator();
	while(i.hasNext()) {
		Empolyee e4 = (Empolyee) i.next();
		System.out.println(e4.id+" "+e4.name+" "+e4.salary);
	}
	
	
}
}
