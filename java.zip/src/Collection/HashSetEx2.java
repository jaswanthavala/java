package Collection;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetEx2 {
public static void main(String[] args) {
	HashSet<Integer> s = new HashSet<Integer>();

	
	s.add(1);
	s.add(2);
	s.add(2);
	
Iterator i = s.iterator();
 while(i.hasNext()){
		System.out.println(i.next());
}
}
}
