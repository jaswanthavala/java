package Collection;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedList1 {
public static void main(String[] args) {
	LinkedList <String>l = new LinkedList<String>();
	l.add("jaswanth");
	l.add("jassu");
	l.add("arjun");
	Iterator i = l.iterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
}
}
