package Collection;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetEx1 {
public static void main(String[] args) {
	TreeSet <String> t = new TreeSet<String>();
	t.add("rockey");
	t.add("jaswanth");
	t.add("soma shekar");
	t.add("thanishika");
	Iterator  i = t.iterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
}
}
