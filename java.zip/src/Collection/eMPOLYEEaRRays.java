package Collection;

import java.util.ArrayList;
import java.util.Iterator;

class empolyee{

		String name;
		int id;
		String phoneno;
		empolyee(String name,int id ,String phoneno){
			this.name=name;
			this.id=id;
			this.phoneno=phoneno;
			
	}
}
public class eMPOLYEEaRRays {
public static void main(String[] args) {
	empolyee e = new empolyee("jaswanth",34,"432546343");
	empolyee e1 = new empolyee("avala",33,"3546571324");
	ArrayList<empolyee >al = new ArrayList<>();
	al.add(e);
	al.add(e1);
	Iterator i =al.iterator();
	while(i.hasNext()) {
		empolyee e2 = (empolyee)i.next();
		System.out.println(e2.name+" "+e2.id+" "+e2.phoneno);
	}
}
}
