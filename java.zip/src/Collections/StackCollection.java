package Collections;

import java.util.List;
import java.util.Stack;

public class StackCollection {
public static void main(String[] args) {
	Stack
	l = new Stack();
	l.push(23134);
	l.push("sardwear0");
	l.push(423433);
	System.out.println(l.pop());
	System.out.println(l.pop());
	System.out.println(l.pop());
}
}
