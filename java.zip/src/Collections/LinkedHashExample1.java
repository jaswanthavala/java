
package Collections;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashExample1 {
public static void main(String[] args) {
	Set s = new LinkedHashSet();
	s.add("vijay");
	s.add("akul");
	s.add("neelama");
	Set s2 = new LinkedHashSet ();
	s2.add("arjun");
	s2.add("6457568");
	s2.add("vijay");
	s2.add(13132);
	s2.add(null);
	s2.addAll(s);
	System.out.println(s2);
	Iterator i = s2.iterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
}
}
