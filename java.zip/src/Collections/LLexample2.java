package Collections;

import java.util.Iterator;
import java.util.LinkedList;

public class LLexample2 {
public static void main(String[] args) {
	LinkedList<String>ll = new LinkedList<>();
	ll.add("jaswanth");
	ll.add("avala");
	ll.add(null);
	ll.add("7246231323");
	LinkedList <String> l = new LinkedList<>();
	l.add(null);
	l.add("jassu");
	l.add("erwrwe");
	ll.addAll(l);
//	System.out.println(ll);
//	ll.retainAll(l);
//	System.out.println(ll);
	Iterator i = ll.iterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
}
}
