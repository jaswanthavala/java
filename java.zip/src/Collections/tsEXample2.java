package Collections;

import java.util.Iterator;
import java.util.TreeSet;

public class tsEXample2 {
public static void main(String[] args) {
	TreeSet <Integer> h = new TreeSet<>();
	h.add(1);
	h.add(2);
	h.add(546);
	TreeSet <Integer> h1 = new TreeSet<>();
	h1.add(23);
	h1.add(43545);
	h1.addAll(h);
	System.out.println(h1);
	System.out.println(h.contains(2));
	System.out.println(h1.containsAll(h));
	Iterator i = h1.iterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
}
}
