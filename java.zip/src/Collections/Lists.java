package Collections;

import java.util.ArrayList;
import java.util.List;

public class Lists {
	public static void main(String[] args) {
		List l = new ArrayList();
		l.add(1);
		l.add("jaswanth");
		l.add(2.4565);
		List l1= new ArrayList();
			l1.add("avala");
			l.addAll(l1);
			l.add(2,"35");
System.out.println(l);
		for(int i=0;i<=l.size()-1;i++) {
			System.out.println(l.get(i));
		}
	}
}
