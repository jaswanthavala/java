package Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;
public class LinkedListExamplee {
public static void main(String[] args) {
	LinkedList l = new LinkedList();
	l.add("jaswanth");
	l.add(2334);
	l.add("3 546457423");
	System.out.println(l);
	LinkedList ll = new LinkedList();
	ll.add("jaswanth");
	ll.add("23");
	ll.add("chandu");
	l.addAll(ll);
	l.add(2,"43535");
//	System.out.println(l);
//	l.remove(1);
//	System.out.println(l);
//	l.removeAll(ll);
//	System.out.println(l);
//	l.addFirst(ll);
//	System.out.println(l);
ListIterator i = l.listIterator();
System.out.println("forward direction :");
	while(i.hasNext())
	{
		System.out.println(i.next());
	}
	System.out.println("backward direction :");
	while(i.hasPrevious()) {
		System.out.println(i.previous());
	}
	
}
}
