package Collections;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class QUEUEcOllections {
public static void main(String[] args) {
	Queue q = new LinkedList();
	q.add("fatty");
	q.add("thiny");
	q.add(12324);
	q.add("we");
	Iterator i = q.iterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
	q.poll();
	q.poll();
	Iterator o = q.iterator()
			;
	while(o.hasNext()) {
		System.out.println(o.next());
	}
}
}
