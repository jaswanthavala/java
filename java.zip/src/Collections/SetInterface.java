package Collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class SetInterface {

	public static void main(String[] args) {
	HashSet<String> s = new HashSet<String>();
		s.add("jaswanth");
		s.add("avala");
		HashSet<String> s1  =new HashSet<String>();
		s1.add("naresh");
		s1.add("lakshmi");
		s1.add("avala");
		s1.add("jaswanth");
		s.addAll(s1);
		Iterator i = s.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		s.retainAll(s1);
		System.out.println(s);
	}

}
