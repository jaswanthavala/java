package Collections;

import java.util.HashSet;
import java.util.Set;

public class SetHashSet {
public static void main(String[] args) {
	Set <String>s = new HashSet<String>();
	s.add("jaswanth");
	s.add("avala");
	Set<String> s1 = new HashSet<String>();
	s1.add("naresh");
	s1.add("hemu");
	s1.add("jaswanth");
	s1.addAll(s);
	for(String a :s1) {
		System.out.println(a);
	}
}
}
