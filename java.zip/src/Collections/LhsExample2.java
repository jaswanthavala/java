package Collections;

import java.util.HashSet;
import java.util.Iterator;

public class LhsExample2 {
public static void main(String[] args) {
	HashSet <String> h = new HashSet<>();
h.add(null);
h.add("jan");
h.add("feb");
h.add("march");
HashSet <String> hs = new HashSet<>();
hs.add("jan");
hs.add(null);
hs.add("jaswanth");
hs.addAll(h);
System.out.println(hs);
Iterator i = hs.iterator();
while(i.hasNext()) {
	System.out.println(i.next());
}
hs.containsAll(h);
System.out.println(hs);
System.out.println(hs.size());
}
}
