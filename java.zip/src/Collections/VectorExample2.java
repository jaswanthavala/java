package Collections;
import java.util.*;

public class VectorExample2 {
public static void main(String[] args) {
	 List<Integer> v = new ArrayList<Integer>();
	v.add(1);
	v.add(45345);
	v.add(4324);
	System.out.println(v);
	List s = new ArrayList();
	s.add("fdfsfdg");
	s.add("oreteojt");
	s.add(2435345);
	s.addAll(v);
	System.out.println(s);
}
}
