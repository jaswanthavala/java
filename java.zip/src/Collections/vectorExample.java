package Collections;

import java.awt.List;
import java.util.Vector;

public class vectorExample {
public static void main(String[] args) {
	Vector s = new  Vector();
	s.add("terters");
	s.add("erithuerg");
	s.add("weuei");
s.addElement("cow");
s.addElement("DOG");
	System.out.println(s);
	for(int i=0;i<=s.size()-1;i++) {
		System.out.println(s.get(i));
	}
}
}
