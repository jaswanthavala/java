package Collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class ListInterface {
public static void main(String[] args) {
	ArrayList<String>al = new ArrayList<String>();
	al.add("jaswanth");
	al.add("avala");
	al.add("8123432424");
	ArrayList<String>a = new ArrayList<String>();
	a.add("avala");
	a.add("chandu");
	a.retainAll(al);
	System.out.println(a);
	al.addAll(a);
	System.out.println(al);
	al.add(2,"jaswanth");
	System.out.println(al);
	al.remove(0);
	System.out.println(al);
	a.clear();
	System.out.println(a);
//	for(int i=0;i<=a.size()-1;i++) {
//		System.out.println(a.get(i));
//	}
Iterator i =al.iterator();
while(i.hasNext()) {
	System.out.println(i.next());
}
}
}
