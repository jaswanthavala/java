package Collections;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class treesETexample {
public static void main(String[] args) {
	Set s = new TreeSet();
	s.add("chandu");
	s.add("jnanu");
	s.add("jaswanth");
	Set s1 = new TreeSet();
	s1.add("avala");
	s1.add("jaswanth");
	s1.add("naresh");
	s1.addAll(s);
	System.out.println(s1);
	Iterator i = s1.iterator();
	while(i.hasNext())
	{
		System.out.println(i.next());
	}
	System.out.println(s1.equals("naresh"));
	
}
}
