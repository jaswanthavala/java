package Arrays;

public class AverageOfArray {
public static void main(String[] args) {
	int arr[]= {1,2,3,4,5,6};
	int len = arr.length;
	int sum =0;
	float ave;
	for(int i=0;i<arr.length;i++) {
		sum = sum+i;
		
	}
	ave = sum/len;
	System.out.println(ave);
}
}
