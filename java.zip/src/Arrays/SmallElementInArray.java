package Arrays;

import java.util.Arrays;

public class SmallElementInArray {
public static void main(String[] args) {
	int a[]= {343,343,44343,32424,3134};
	Arrays.sort(a);
	System.out.println(a[0]);
}
}
