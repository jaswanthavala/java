package Arrays;
import java.util.Arrays;
public class ThirdLargest {
public static void main(String[] args) {
int a[]= {342,4242,213,56,1314};
Arrays.sort(a);
System.out.println(Arrays.toString(a));
for(int i=a.length-1;i>=0;i--) {
	System.out.print(a[i]+" ");
}
System.out.println( "third largest element "+a[2]);
System.out.println("second lagrest element "+a[1]);
System.out.println("first largest element "+a[0]);
}
}
