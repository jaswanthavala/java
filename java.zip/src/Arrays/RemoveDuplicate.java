package Arrays;

import java.util.Arrays;

public class RemoveDuplicate {
public static void main(String[] args) {
	int arr[]= {1,12,2,3,1,4,5,32,5,34,4};
	Arrays.sort(arr);
	System.out.println(Arrays.toString(arr));
	for(int i=0;i<arr.length;i++) {
			if(i==0||arr[i]!=arr[i-1]) {
				System.out.print(arr[i]+" ");
			}
		}
	}
}

