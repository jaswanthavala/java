package Arrays;

public class EvenPosition {
public static void main(String[] args) {
	int a[]= {4,45,67,54,63};
	int sum=0;
	for(int i=0;i<a.length;i++) {
		if(i%2==0) {
			System.out.print(a[i]+" ");
			sum =sum+a[i];
			System.out.println(" "+sum);
		}
	}
}
}
