package Arrays;

import java.util.Arrays;

public class LeftRotations {
public static void main(String[] args) {
	int a[]= {1,3,2,4,5,6};
	 Arrays.sort(a);
	 int n =3;
	 for(int i=0;i<=n;i++) {
	 int b =a[0];
	 int j;
		for(j=0;j<a.length-1;j++) {
			a[j]=a[j+1];
		}
		a[j]=b;
		System.out.println();
	 }
		for(int i=0;i<a.length;i++) {
			System.out.print(a[i]+" ");
		}
	 }
}

