package Arrays;
public class LargeElements {
public static void main(String[] args) {
	int a[]= {34,435,2342,43,5454};
	int j = 0;
	for(int i=1;i<a.length;i++) {
		j=a[0];
			if(a[i]>j ) {
				j=a[i];
		}
	}
	System.out.println(j);	
	}
	}


