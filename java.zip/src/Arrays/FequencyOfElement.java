package Arrays;

import java.util.Arrays;

public class FequencyOfElement {
	public static void main(String[] args) {
		
		int arr[]= {433,434,232,433,454};
		
		Arrays.sort(arr);
		int count=1;
		for(int i=1;i<arr.length;i++) {
				if(arr[i]==arr[i-1]) {
					count++;
				}
				else {
					System.out.println(arr[i-1]+" "+count);
					count=1;
				}
			}
		System.out.println(arr[arr.length-1]+" "+count);
		
	}

}
