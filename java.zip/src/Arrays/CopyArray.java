package Arrays;

public class CopyArray {
 public static void main(String[] args) {
	int a[]= {3,454,54,324,65};
	int b[]= new int [a.length];
	System.arraycopy(a, 0, b, 0, a.length);
			for(int i=0;i<b.length;i++){
				System.out.print(b[i]+" ");
		}

	}
}

