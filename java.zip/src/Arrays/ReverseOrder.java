package Arrays;

public class ReverseOrder {
public static void main(String[] args) {
	int a[]= {2,3,4,5,6,8};
	for(int i=a.length-1;i>=0;i--) {
		System.out.print(a[i]+" ");
	}
}
}
