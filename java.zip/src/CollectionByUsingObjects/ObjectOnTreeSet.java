package CollectionByUsingObjects;

import java.util.TreeSet;
import java.util.TreeSet;

class AtmCard implements Comparable<AtmCard> {
    int balance;
    int pin;
    String holderName;

    AtmCard(int balance, int pin, String holderName) {
        this.balance = balance;
        this.pin = pin;
        this.holderName = holderName;
    }

    @Override
    public int compareTo(AtmCard other) {
        return Integer.compare(this.balance, other.balance);
    }

    @Override
    public String toString() {
        return holderName + " " + pin + " " + balance;
    }
}

public class ObjectOnTreeSet {
    public static void main(String[] args) {
        AtmCard a = new AtmCard(324324, 3455, "Jaswanth");
        AtmCard a1 = new AtmCard(32425454, 4545, "Avala");

        TreeSet<AtmCard> t = new TreeSet<>();
        t.add(a);
        t.add(a1);

        for (AtmCard b : t) {
            System.out.println(b);
        }
    }
}

