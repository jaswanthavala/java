package CollectionByUsingObjects;

import java.util.Iterator;
import java.util.LinkedList;

class Employee{
	String name;
	int id;
	String phoneno;
	Employee(String name ,int id ,String phoneno){
		this.name=name;
		this.id=id;
		this.phoneno=phoneno;
	}
}
public class ObjectOnLinkedList {
public static void main(String[] args) {
	Employee e = new Employee("jaswanth",1,"432435344");
	Employee e1 = new Employee("avala",2,"2433546745");
	LinkedList<Employee>l = new LinkedList<Employee>();
	l.add(e1);
	l.add(e);
	Iterator i = l.iterator();
	while(i.hasNext()) {
		Employee e2 = (Employee) i.next();
		System.out.println(e2.id+" "+e2.name+" "+e2.phoneno);
	}
}
}
