package CollectionByUsingObjects;

import java.util.ArrayList;
import java.util.Iterator;

class Student{
	int id;
	String name;
	Student(int id ,String name){
	this.id=id;
	this.name=name;
	
	}
}
public class ObjectOnArrayaList {
public static void main(String[] args) {
	Student s = new Student(1,"vijay");
	Student s1 = new Student(2,"arjun");
	Student s2 = new Student(3,"jaswanth");
	ArrayList<Student> a =new ArrayList<Student>();
	a.add(s);
	a.add(s1);
	a.add(s2);
	Iterator i = a.iterator();
	while(i.hasNext())
	{
		Student s3 = (Student)i.next();
		System.out.println(s3.id+" "+s3.name);
	}
}
}
