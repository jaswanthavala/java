package CollectionByUsingObjects;

import java.util.LinkedHashSet;

class Bike{
	int price;
	String company;
	Bike(int price ,String company){
		this.price=price;
		this.company=company;
	}
}
public class ObjectOnLINKEDHashSet {
public static void main(String[] args) {
	Bike b = new Bike(234244,"pulsar");
	Bike b1 = new Bike(243245,"hero");
	LinkedHashSet<Bike>l = new LinkedHashSet<>();
	l.add(b);
	l.add(b1);
	for(Bike s :l) {
		System.out.println(s.company+" "+s.price);
	}
}
}
