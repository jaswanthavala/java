package CollectionByUsingObjects;

import java.util.HashSet;
//import java.util.Iterator;

class demo{
	int id ;
	String name;
	String phonenumber;
	demo(int id,String name ,String phonenumber){
		this.id=id;
		this.name=name;
		this.phonenumber=phonenumber;
	}
}
public class ObjectOnHashSet {
public static void main(String[] args) {
	demo d = new demo(1,"naresh","5345643245");
	demo d1 = new demo(1,"naresh","534564324");
	HashSet <demo> h = new HashSet<demo>();
	h.add(d);
	h.add(d1);
	for(demo s :h) {
		System.out.println(s.id+" "+s.name+" "+s.phonenumber);
	}
}
}
