package CollectionByUsingObjects;

import java.util.Iterator;
import java.util.Stack;

class car{
	String company;
	int price;
car(String company,int price){	
	this.company=company;
	this.price=price;
}
public String toString() {
    return company + " " + price;
}
}
public class ObjectOnStack {
public static void main(String[] args) {
	car c = new car("toyto",4243545);
	car c1 = new car("maruthi",45465462);
	car c2 = new car("tata",423554);
	car c4 = new car("tata",423554);
	Stack <car>s = new Stack<car>();
	s.push(c);
	s.push(c1);
	s.push(c2);
	s.push(c4);
//	Iterator i = s.iterator();
//	while(i.hasNext()) {
//		car c3 = (car)i.next();
//		System.out.println(c3.company+" "+c3.price);
//		
	System.out.println(s.pop());
	System.out.println(s.pop());
	System.out.println(s.pop());
	System.out.println(s.pop());
	//}
}
}
