package CollectionByUsingObjects;

import java.util.Iterator;
import java.util.Vector;

class worker{
	int id ;
	String name ;
	worker( int id ,String name){
		this.id=id;
		this.name=name;
	}
}
public class ObjectOnVector {
public static void main(String[] args) {
	Vector<worker> w = new Vector<worker>();
	worker w1 = new worker(1,"sri");
	worker w2 = new worker(2,"srisha");
	w.add(w1);
	w.add(w2);
	Iterator i = w.iterator();
	while(i.hasNext()) {
		worker w3 =(worker)i.next();
		System.out.println(w3.id+" "+w3.name);
	}
}
}
