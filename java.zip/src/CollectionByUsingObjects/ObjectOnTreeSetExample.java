package CollectionByUsingObjects;

import java.util.Iterator;
import java.util.TreeSet;

class tree implements Comparable<tree>{
	int id;
	String name;
	tree(int id , String name){
		this.id=id;
		this.name=name;
	}
	public int compareTo(tree s) {
		if(id>s.id) {
			return 1;
		}
		else if(id<s.id) {
			return -1;
		}
		else {
			return 0;
		}
	}
	public String toString() {
		return id+" "+name ;
	}
}
public class ObjectOnTreeSetExample {
public static void main(String[] args) {
	tree t  = new tree(1,"jaswanth");
	tree t1 = new tree(2,"avala ");
	TreeSet<tree> ts = new TreeSet<tree>();
	ts.add(t1);
	ts.add(t);
	for(tree w :ts) {

		System.out.println(w);
	}
	
}
}
