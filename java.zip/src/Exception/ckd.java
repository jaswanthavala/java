package Exception;

public class ckd extends Exception {
    public static void main(String[] args) throws ArithmeticException {
       try{ 
        if(2<3){
            throw new ArithmeticException("exception occured");
        }
    }
    catch(ArithmeticException e){
        System.out.println(e);
    }
    }
}
