package Exception;

public class pattern {
    public static void main(String[] args) {
        int n=5;
        for(int i=0;i<=5;i++){
            if(i!=5){
           for(int j=5;j>i;j--){
            System.out.print(" ");
           }
           for(int k=i;k>=0;k--){
            if(k==i )
            System.out.print("*");
            else
            System.out.print(" ");
           }
           if(i>=1 || i<5){
           for(int k=0;k<i;k++){
            if(k==i-1)
            System.out.print("*");
            else
           System.out.print(" ");
        }}

      
         
    }
    else{
        for(int k=0;k<=10;k++){
            System.out.print("*");
        }
    } System.out.println();
        }    
    }
    
    
}
