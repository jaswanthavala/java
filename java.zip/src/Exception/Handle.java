package Exception;
class A{
	void method() throws Exception {
		throw new Exception("custom");
	}
}
public class Handle {
public static void main(String[] args) {
	try {
		A a = new A();
		a.method();
		
	}
	catch(Exception e){
		System.out.println(e.getMessage());
	}
	System.out.println("rest code is excuted");
}
}
