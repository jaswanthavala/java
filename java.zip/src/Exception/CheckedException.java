package Exception;

public class CheckedException extends Exception {
	public static void main(String[] args) throws ArrayIndexOutOfBoundsException{
		try {
			int arr[]= {12,32,4,32,34,32};
			System.out.println(arr[5]);
			throw new ArrayIndexOutOfBoundsException("Exception occured");
		
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
		finally {
			System.out.println("close the code");
		}
	}

}
