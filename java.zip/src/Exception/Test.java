package Exception;
class MyException extends Exception{
	
}
public class Test {
public static void main(String[] args) {
	try {
		throw new MyException();
	}
	catch (MyException e) {
		System.out.println("myexception occurs");
		System.out.println(e.getMessage());
	}
	System.out.println("rest code will be executed");
}
}
