package Exception;

import java.io.FileReader;
import java.io.IOException;

public class EXample5 {
public static void main(String[] args) throws IOException {
	FileReader f = new FileReader("java.txt");
	System.out.println(f.read());
}
}
