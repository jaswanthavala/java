package Exception;


class parent
{
	void message()  {
		System.out.println("send a message");
	}
}
public class Overridden extends parent{
	void message() throws ArithmeticException {
		System.out.println("Exception occured");
	}
public static void main(String[] args) {
	parent p = new Overridden();
	p.message();
}
}
