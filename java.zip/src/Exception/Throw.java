package Exception;

public class Throw {
public void num(int n)  {
	if(n<1) {
		throw new ArithmeticException("cannot be calcuate square to negative numbers");
	}
	else {
		System.out.println(n +" square is equals "+  n*n);
	}
}
	public static void main(String[] args)  {
		Throw obj  = new Throw();
		obj.num(-3);

	}

}
