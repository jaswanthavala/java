package Exception;

public class example1 {
public static void main(String[] args) {
	try {
		int x = 100/0;
	}
	catch(Exception e) {
		//System.out.println(e);
		e.printStackTrace();
		//System.out.println(e.getMessage());
	}
	
}


}
