package Exception;

public class Arrray {
public static void main(String[] args) {
	int i= 2;
	int j =0;
	int arr []=new int [5];
	try {
		  j=20/i;
		System.out.println(arr[1]);
		System.out.println(arr[5]);
	}
	catch(Exception e) {
		System.out.println("catch the exeception");
	}

	System.out.println(j);
}
}
