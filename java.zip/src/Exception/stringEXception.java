package Exception;
class sample extends Exception{
	sample(String a){
		super(a);
	}
}
public class stringEXception {

	public static void main(String[] args) {
		String a = "miracle software system";
		try{
			for (int i =0;i<=a.length()+1;i++) {
			char ch = a.charAt(i);
			System.out.print(ch);
		}
			
		}
		catch(StringIndexOutOfBoundsException e) {
			System.out.println(" "+e.getMessage());
			System.out.println("Exection handled");
		}
		finally {
			System.out.println("Exection recovery");
		}

	}

}
