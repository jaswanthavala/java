package Exception;
import java.util.Arrays;

public class UserExceptionsss {

	public static void main(String[] args) {
	// TODO Auto-generated method stub
String s ="abcabbcdfffffrtr";
String[] s1=s.split("");
Arrays.sort(s1);
int j=0;
int count =0;
String res="";
for(int i=0;i<=s1.length-1;i++) 
{  
	count=0;
	for(j=i;j<s1.length;j++)
	{
		if((s1[i]).equals(s1[j])) 
		{
			
			count++;
		}

}
res=res+s1[i];
i=i+(count-1);
	
}
System.out.println(res);
	

}}


//       *
//      *  *
//     *    *
//    *      *
//    ********

