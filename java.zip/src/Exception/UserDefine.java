package Exception;

import java.util.Scanner;

class user extends Exception{
	user(String s){
		super();
	}
}
public class UserDefine {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	int age = s.nextInt();
	s.close();
	try {
		if(age<18) {
throw new user("you are not eligible to vote");

		}
		else {
			System.out.println("you are eligible to vote");
			System.out.println("welcome to vote...");
		}
	}
	catch(Exception e ) {
		System.out.println(e.getMessage());
	}
	System.out.println("rest of code");
}
}
