package Exception;
class Demo extends Exception{
	public Demo(String s) {
		super(s);
	}
}
public class UserDemo {
public static void main(String[] args) {
	try {
		int x=140;
		if(x>40) {
			throw new Demo("student is invalid");
		}
		else{
			System.out.println("Student is valid");
		}
	}
	catch(Demo e) {
		System.out.println("Exception is occured");
		System.out.println(e);
	}
	
}
}
