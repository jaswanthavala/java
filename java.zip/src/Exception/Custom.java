package Exception;
class Student extends Exception{
	Student(String n){
		super(n);
	}
}
public class Custom {
public static void main(String[] args) {
	int student = 140;
	try {
		if(student>40) {
			throw new Student("The student is not from this class");
		}
		else {
			System.out.println("The student is from this class");
		}
	}
		catch(ArithmeticException |Student e)
		{
	System.out.println("catch the exception");		
		System.out.println("exception occurs"+ e);
	}
	System.out.println("rest of code is executed");
}
}
