package Exception;

import java.util.Scanner;

class evenorodd extends Exception{
	evenorodd(String l){
		super(l);
		
	}
}
public class EvenOrOdd {
public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		int n =sc.nextInt();
		sc.close();
		try {
			if(n%2!=0) {
				throw new evenorodd("odd exception");
			}
			else {
				System.out.println("even");
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			
		}
System.out.println("rest code is excuted");
}
}
