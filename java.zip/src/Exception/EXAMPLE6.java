package Exception;

import java.util.Scanner;

import Oops.Arithmetic;

class Exam extends Exception{
	Exam(String s ){
		super(s);
	}
}
public class EXAMPLE6 {
public static void main(String[] args) {
	Scanner s  =new Scanner(System.in);
	int marks = s.nextInt();
	try {
		if(marks<35) {
			throw new Exam("you failed in this subject");
		}
		else if(marks>=35 &&marks<=100) {
			System.out.println("you are passed in this subject");
		}
		else {
			System.out.println("this student is not valid ");
		}
	}
	catch( Exception e ){
		System.out.println(e);
	}
}
}
