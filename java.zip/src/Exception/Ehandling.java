package Exception;
import java.util.*;
import Oops.Arithmetic;

public class Ehandling {
public static void main(String[] args) {
	try {
		int n = 50/0;
		System.out.println(n);
		
	}
	catch(ArithmeticException e) {
		System.out.println("divide by 0");
	}
	finally {
		System.out.println("rest of code");
	}
}
}
