package Exception;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStreamReader;

public class examapl2 {
private static InputStreamReader file;

public static void main(String[] args) {
	try{
		FileReader file = new FileReader("java.txt");
	}
	catch(Exception e) {
//	e.printStackTrace();
	System.out.println(e);
//	}
//	finally {
//		System.out.println(file.read());
	}
	
}
}
