package Exception;
import java.util.*;

public class Custome {
public static void main(String[] args) {
	int n = 14;
	if(n<18) {
		throw new ArithmeticException("invaild for a vote");
	}
	else {
		System.out.println("eligible to vote");
	}
	System.out.println("rest of a code");
}
}
