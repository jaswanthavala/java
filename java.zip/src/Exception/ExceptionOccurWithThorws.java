package Exception;
class B{
	void main() throws Exception{
		
		System.out.println("Exception occurs");
	}
}
public class ExceptionOccurWithThorws {

	public static void main(String[] args) throws Exception  {
	 B b = new B();
	 b.main();
System.out.println("normal flow");
	}

}
