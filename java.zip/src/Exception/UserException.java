package Exception;
class User extends Exception{
	User(String s){
		super(s);
	}
}
public class UserException {
	public static void main(String[] args){
		int student = 10000;
		try {
			if(student>1000) {
				throw new User("student is invalid");
			}
			else {
				System.out.println("student is valid");
			}
		}
			catch(ArithmeticException | User e){
				System.out.println("catch the exception");
				System.out.println("exception occur"+ e);
			}
		System.out.println("rest the code");
	}

}
