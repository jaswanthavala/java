package Exception;
class demo extends Exception{
public 	demo(String s)
	{
		super(s);
	}
}
public class Exceptions {

	public static void main(String[] args) {
	int marks = 25;
	try {
		if(marks<35) {
			throw new demo("This student is failed");
		}
		else if(marks>=35&&marks<=100) {
			System.out.println("This student is  pass");
		}
		else {
			System.out.println("This student is invalid ");
		}
	}
	catch (ArithmeticException | demo e){
		System.out.println("catch the exception ");
		System.out.println("exception occurs "+e);
	}
	System.out.println("rest the code");
	}

}
