package String;

public class capital {

	public static void main(String[] args) {
		String s ="miracle software systems";
		String r[]=s.split("\\s");
		String c="";  
	    for(String w:r){  
	        String first=w.substring(0,1);  
	        String afterfirst=w.substring(1);  
	       c+=first.toLowerCase()+afterfirst.toUpperCase()+" ";  
	        System.out.println(c);
	    }
	}

}
