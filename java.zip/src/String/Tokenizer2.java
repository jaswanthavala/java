package String;

import java.util.StringTokenizer;

public class Tokenizer2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     StringTokenizer b = new StringTokenizer("Hi this is avala jaswanth from nathavalasa");
   
     System.out.println(b.countTokens());
	}

}
