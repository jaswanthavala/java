package String;

import java.util.Scanner;

public class CountTheNumberOfWords {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter a string name :");
	String a = s.nextLine();
	String sc [] =a.trim().split(" ");
	int leng = sc.length;
	System.out.println(leng);
	s.close();
}
}
