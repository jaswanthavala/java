package String;

public class replace {

	public static void main(String[] args) {
		String s="he is a good programmer";
		String a=s.replace("is", "became");
		System.out.println(a);

	}

}
