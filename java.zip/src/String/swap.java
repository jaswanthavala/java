package String;

import java.util.Scanner;

public class swap {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter two strings :");
	String a = s.next();
	int c = a.length();

	String b = s.next();
	int d = b.length();
	a=a+b;
	System.out.println(a.substring(c));
	System.out.println( a.substring(0,c));
	s.close();
}
}
