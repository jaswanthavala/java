package String;

public class Builder1 {
public static void main(String []args) {
	StringBuilder s = new StringBuilder("string");
	s.replace(1, 4, "builder");
	System.out.println(s);
	s.delete(1, 3);
	System.out.println(s);
}
}
