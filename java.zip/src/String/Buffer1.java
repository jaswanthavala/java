package String;

public class Buffer1 {
public static void main(String []args) {
	StringBuffer s = new StringBuffer("hello");
	s.replace(1, 2, "java");
	System.out.println(s);
	s.delete(0, 2);
	System.out.println(s);
}
}
