package String;

import java.util.Scanner;

public class StringReverse {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		sc.close();
		String s ="";
		StringBuilder sb = new StringBuilder(str);
		
		for(int i=sb.length()-1;i>=0; i--) {
			s =s+sb.charAt(i);
		}
		System.out.print(s);
	}

}
