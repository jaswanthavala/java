package String;
public class Builder {

	public static void main(String[] args) {
		StringBuilder s = new StringBuilder("hello");
		s.append("java");
		System.out.println(s);
		s.insert(2, "lang");
		System.out.println(s);

	}

}
