package String;

public class IndividualChar {

	public static void main(String[] args) {
		String s ="hello world";
		for(int i=0;i<s.length();i++) {
			char ch= s.charAt(i);
			System.out.println(ch);
		}
		
		
	}

}
