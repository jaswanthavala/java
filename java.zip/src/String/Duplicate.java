package String;

import java.util.Scanner;

public class Duplicate {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.print("enter a string name :");
	String a = s.next();
	for(int i=0;i<=a.length()-1;i++) {
		char ch = a.charAt(i);
		for(int j=i+1;j<=a.length()-1;j++) {
			char b = a.charAt(j);
			if(ch==b) {
				System.out.println(ch);
			}
		}
	}
}
}
