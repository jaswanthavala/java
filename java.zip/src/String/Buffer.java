package String;

public class Buffer {

	public static void main(String[] args) {
		StringBuffer sb=new StringBuffer("java");
		//append() method
		sb.append(" world");
		System.out.println(sb);
		sb.insert(1, "string");
		System.out.println(sb);
		int a=sb.length();
		System.out.println(a);
		int b =sb.capacity();
		System.out.println(b);
		System.out.println(sb.reverse());
	}

}
