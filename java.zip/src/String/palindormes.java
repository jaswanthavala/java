package String;

public class palindormes {

	public static void main(String[] args) {
		String s[]= {"amma","aha","abba","boy"};
		int count=0;
		for(String a:s) {
			if(ispalindorme(a)) {
				count++;
			}
		}
		System.out.println(count);
}


public static boolean ispalindorme(String k) {
	int i=0,j=k.length()-1;
	while(i<j) {
		if(k.charAt(i)!=k.charAt(j)) {
			return false;
		}
		i++;
		j--;

	}
	return true;
}
}