package String;

import java.util.StringTokenizer;

public class Tokenizer {

	public static void main(String[] args) {
		StringTokenizer s =new StringTokenizer("jaswanth joined in mss on yesterday");
		while(s.hasMoreTokens()) {
			 System.out.println(s.nextToken());
		}

	}

}
