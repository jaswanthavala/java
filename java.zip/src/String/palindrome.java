package String;
public class palindrome {
public static void main(String[] args) {
	String s[]= {"racecar","abba","hii","hello"};
	int count=0;
	for(String w:s) {
	if(isPalindrome(w)) {
		count++;
	}
}
System.out.println("number of palindrome words is "+count);
}
public static boolean isPalindrome(String n) {
	int i=0,j=n.length()-1;
	while(i<j) {
		if(n.charAt(i)!=n.charAt(j)) {
			return false;
			
		}
		i++;
		j--;
	}
	return true;
}
}
