package String;

import java.util.StringTokenizer;

public class Tokenizer1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       StringTokenizer a = new StringTokenizer("hi everyone this is avala jaswanth");
       while(a.hasMoreTokens()) {
    	   System.out.println(a.nextElement());
       }
	}

}
