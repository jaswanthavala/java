package String;

public class FirstCharToUpperCase {
public static void main(String[] args) {
	String s = "miracle software";
	String s1 ="";
	s=s+" ";
	for(int i=0; i<s.length();i++) {
		char ch=s.charAt(i);
		if(ch!=' ') {
			s1= s1+ch;
			s1=s1.substring(0,1).toUpperCase()+s1.substring(1);
		}
		else {
			System.out.println(s1);
			s1="";
		}
	}
}
}
