package String;

public class SpLIt {
public static void main(String[] args) {
	String s ="hello this is avala jaswanth";
	String s1[] =s.split(" ");

		for(int i=0;i<=s1.length-1;i++) {
			String s2 = s1[i].substring(0, 1).toUpperCase()+s1[i].substring(1);
			System.out.print(s2+" ");
		}
		
		
	}
}

