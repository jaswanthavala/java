package ControlStatement;
import java .util.Scanner;
public class Q18 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		s.close();
		System.out.println(sumofDigits(n));
	}
public static int sumofDigits(int n) {
	String s =String.valueOf(n);
	int sum=0;
	for(int i=1;i<=s.length();i+=2) {
		 sum += Character.getNumericValue(s.charAt(i));
	}
	return sum;
	
}
}
