package ControlStatement;
import java.util.Scanner;
public class Q22 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("enter a number: ");
		int n =s.nextInt();
		s.close();
		int evenSum=0;
		int oddSum=0;
		for(int i=1;i<=2*n;i++) {
			if(i%2==0) {
				evenSum =evenSum+i;
				
			}
			else
			{
				oddSum=oddSum+i;
			}
			
			
		}
		
		System.out.println(evenSum+" ");
		System.out.println(oddSum+" ");
	}

}
