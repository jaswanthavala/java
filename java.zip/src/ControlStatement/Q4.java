package ControlStatement;

import java.util.Scanner;

public class Q4 {

	public static void main(String[] args) {
		Scanner sc =new Scanner (System.in);
		int n =sc.nextInt();
		sc.close();
		if(n<=34) {
			System.out.println("The student is fail");
		}
		else if(n>=35&&n<=50) {
			System.out.println("The student is pass and the grade is D");
		}
		else if(n>50&&n<=70) {
			System.out.println("The student is pass and the grade is C");
		}
		else if(n>70&&n<= 90) {
			System.out.println("The student is pass and the grade is B");
		}
		else if(n>90&&n<=100) {
			System.out.println("The student is pass and the grade is A");
		}
		else {
			System.out.println("The student is invaild");
			
		}

	}

}
