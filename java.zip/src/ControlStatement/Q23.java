package ControlStatement;
import java.util.Scanner;
public class Q23 {

	public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("enter a number :");
	int n=s.nextInt();
	s.close();
	int rev=0;
	while(n!=0) {
		int m =n%10;
		rev =rev*10+m;
		n=n/10;
	}
System.out.println(rev);
	}

}
