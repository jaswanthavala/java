package ControlStatement;
import java.util.Scanner;
public class Q42 {

	public static void main(String[] args) {
		Scanner s =new Scanner(System.in);
		System.out.println("enter a number :");
		int n =s.nextInt();
		s.close();
	
		while(n>9) {
			int sum=0;
			int rem=0;
			while(n>0) {
			rem=n%10;
			sum=sum+rem*rem;
			n=n/10;
			}
			n=sum;
		}
		if(n==1) {
			System.out.println("number is happy number");
		}
		else {
			System.out.println("not a happpy number");
		}
		
	}

}
