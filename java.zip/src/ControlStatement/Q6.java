package ControlStatement;

public class Q6 {

	public static void main(String[] args) {
		int a =56;
		int b =65;
		int max=(a>b)?a:b;
System.out.println(max);
	}

}
