package ControlStatement;

public class Q21 {
public static void main(String[] args) {
	int n =134566;
	int last=n%10;
	int first =n;
	while(first>=10) {
		first /=10;
	}
	System.out.println(first+last); 
}
}
