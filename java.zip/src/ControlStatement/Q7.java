package ControlStatement;



public class Q7 {

	public static void main(String[] args) {
		
		int n=20;
		for(int i=1;i<=n;i++) {
    int sq =i*i;			
  System.out.println(sq);
}
	}

}
