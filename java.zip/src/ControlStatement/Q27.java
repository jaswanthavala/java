package ControlStatement;
import java.util.Scanner;
public class Q27 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("enter a  number :");
		int n=s.nextInt();
		s.close();
		int sum=0;
		int i=1;
		while(i<=n/2) {
			if(n%i==0) {
				sum=sum+i;
				
			}

		}
		if(sum==n) {
			System.out.println(n+" is a prefect number");
		}
		else {
			System.out.println(n+" is a not prefect number");
		}
	}

	}

