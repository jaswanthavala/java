package ControlStatement;
import java.util.Scanner;
public class Q16 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("enter a number :");
		int n = s.nextInt();
		s.close();
		int digit =0;
		while(n!=0) {
			int num =n%10;
			if(num>digit) {
				digit =num;
			}
			n=n/10;
		}
System.out.println(digit);
	
	}

}
