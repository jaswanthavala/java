package ControlStatement;
import java.util.Scanner;
public class Q1 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("enter a number :");
		int n = s.nextInt();
		s.close();
		if(n>0) {
			System.out.println("the number is positive ");
		}
		else {
			System.out.println("The number is negative");
		}

	}

}
