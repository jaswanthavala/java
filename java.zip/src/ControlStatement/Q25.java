package ControlStatement;
import java.util.Scanner;
public class Q25 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a  number :");
		int n = sc.nextInt();
		sc.close();
		int temp=0;
		for(int i=1; temp<=n;i++) {
		 int count=0;
			for(int j=1; j<=i;j++) {
				if(i%j==0) {
					count++;
				}
				}
				if(count==2) {
					System.out.print(i+" ");
					temp++;
				}
			}

	}

}
