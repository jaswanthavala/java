package ControlStatement;

public class Q32 {

	public static void main(String[] args) {
		int a=34;
		int b=67;
		int c=65;
		int min=(a<b)?a:b;
        int min1=(b>c)?b:c;
        int min2=(a<c)?c:a;
        System.out.println(min);
        System.out.println(min1);
        System.out.println(min2);
	}

}
