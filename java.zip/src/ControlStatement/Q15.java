package ControlStatement;

public class Q15 {

	public static void main(String[] args) {
	
		int n = 6;
	//	System.out.println("enter a number");
		int n1=1;
		int n2=2;
		for(int i=1;i<=n;i++) {
		  int n3=n1+n2; 
		  System.out.print(n1+" ");
		  n1=n2;
		  n2=n3;
		//  System.out.print(n1+" ");
	   }
	   

	}

}
