package ControlStatement;
import java.util.Scanner;
public class Q17 {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("enter a number :");
	int n = s.nextInt();
	s.close();
	int sum=sumofDigits(n);
	System.out.println(sum);
	
	
}
public static int sumofDigits(int n) {
	if(n==0) {
		return 0;
	}
	return n%10+sumofDigits(n/10);
}
}
