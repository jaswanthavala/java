package ControlStatement;
import java.util.Scanner;
public class Q24 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number :");
		int n = sc.nextInt();
		sc.close();
		int count=0;
		if(n>1) {
			for(int i=1;i<=n;i++) {
				if(n%i==0) {
					count++;
				}
				}
				if(count==2) {
					System.out.println(n +"is a prime");
				}
				else {
					System.out.println("is not a prime");
				}
			}
		}
	}

