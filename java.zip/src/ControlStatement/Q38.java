package ControlStatement;

public class Q38 {

	public static void main(String[] args) {
		int arr[]= {6,7,56,89,34};
		int large=0;
		int small=arr[0];
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>large) {
				large =arr[i];
			}
			else if(arr[i]<small) {
				small=arr[i];
			}
		}
		System.out.println(large);
		System.out.println(small);
		}
}
