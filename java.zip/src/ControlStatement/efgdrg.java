package ControlStatement;

public class efgdrg {
public static void main(String[] args) {
	int s = 21;
	int a =23;
	s =s^a;
	a= s^a;
	s=s^a;
	System.out.println(s+" "+a);
}
}
