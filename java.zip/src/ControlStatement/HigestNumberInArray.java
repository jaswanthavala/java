package ControlStatement;

public class HigestNumberInArray {

	public static void main(String[] args) {
		int arr[]= {4,56,65,34,78};
		int big=0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>big) {
				big =arr[i];
				
			}
		}
System.out.println(big);
	}

}
