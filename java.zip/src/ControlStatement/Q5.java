package ControlStatement;

public class Q5 {
	static void Character(char ch) {
	
		if(Character.isUpperCase(ch)) {
			System.out.println(ch + " it is a upper case");
		}
		else if(Character.isLowerCase(ch)) {
			System.out.println(ch + " it is a lower case");
		}
		else if(Character.isDigit(ch)) {
			System.out.println(ch+ " it is a digit");
		}
		else {
			System.out.println(ch + " it is a special char");
		}
	}

	public static void main(String[] args) {
		char ch ='6';
		Character(ch);

	}

}
