package ControlStatement;

public class Q34 {

	public static void main(String[] args) {
		int arr[]= new int[]{4,56,78,98,243};
		int arr1[]=new int[arr.length] ;
		for(int i=0;i<arr.length;i++) {
			arr1[i]=arr[i];
			System.out.print(arr1[i]+" ");
		}
		

	}

}
