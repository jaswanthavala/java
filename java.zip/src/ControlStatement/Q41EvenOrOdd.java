package ControlStatement;

public class Q41EvenOrOdd {

	

	public static void main(String[] args) {
		int arr[]= {1,2,3,4,5,6,7,8};
		int even = arr[0];
		int odd= arr[0];
		for(int i=0;i<arr.length-1;i++) {
			if(i%2==0) {
				even=i;
			}
			else {
				odd=i;
			}
		}
		
		System.out.println(even);
		System.out.println(odd);
	}

}
