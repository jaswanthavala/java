package ControlStatement;
import java.util.Scanner;
public class Q13 {

	public static void main(String[] args) {
		Scanner s =new Scanner(System.in);
		System.out.println("enter a number :");
		
		int n  =s.nextInt();
		s.close();
		for(int i=1;i<=n;i++) {
			int m = i*i;
			System.out.println(i+"=" +m);

		}
		//System.out.println(m);

	}

}
