package ControlStatement;

public class Q10Do {

	public static void main(String[] args) {
		int i=0;
		int n=25;
		do {
			System.out.println(i);
		   i=	i+2;
		}
		while(i<n);

	}

}
