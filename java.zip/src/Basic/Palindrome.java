package Basic;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		Scanner s  = new Scanner(System.in);
		System.out.println("enter a  string here :");
	String a= s.nextLine();
	s.close();
	String b ="";
	for(int i=a.length()-1;i>=0;i--) {
		b = b+a.charAt(i);
	}
	if(b.equals(a)) {
		System.out.println("yes it is a palindrome");
	}
	else {
		System.out.println("no it is a not palindrome");
	}
	}

}
