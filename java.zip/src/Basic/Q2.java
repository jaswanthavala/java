package Basic;

public class Q2 {

	public static void main(String[] args) {
		int i=67;
		System.out.println(i);

	}

}
