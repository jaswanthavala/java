package Basic;

public class Q3 {

	public static void main(String[] args) {
		double  f=23.1256;
		int n=(int) (f);
		System.out.println(n);
	}

}
