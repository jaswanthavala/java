package Basic;
import java.util.Scanner;
public class Vote {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("enter a number :");
	int n  =s.nextInt();
	s.close();
	if(n>=18) {
		System.out.println("Ready to vote");
	}
	else {
		System.out.println("not ready to vote");
	}
}
}
