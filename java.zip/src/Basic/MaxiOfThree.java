package Basic;

import java.util.Scanner;

public class MaxiOfThree {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	int a = s.nextInt();
	int b =s.nextInt();
	int c = s.nextInt();
	s.close();
	int max =a;
	if(b>max){
		max = b;
	}
	if(c>max) {
		max =c;
	}
	System.out.println(max);
}
}
