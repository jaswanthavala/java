package Basic;
import java.util.Scanner;
public class Q6b {
public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	int n=sc.nextInt();
	sc.close();
	int cube =n*n*n;
	System.out.println(cube);
}
}
