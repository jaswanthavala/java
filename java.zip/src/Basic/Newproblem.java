package Basic;

public class Newproblem {
public static void add(String name , int n) {
	for(int i=1; i<=n;i++) {
		System.out.println(name);
	}
}
	public static void main(String[] args) {
		add("java" ,3);
		add("raj" ,4);

	}

}
