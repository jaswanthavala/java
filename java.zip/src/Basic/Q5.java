package Basic;

public class Q5 {

	public static void main(String[] args) {
		int i=45;
		int j=55;
		int k=50;
		int sum =i+j+k;
		int ave=(i+j+k)/3;
		System.out.println(sum);
		System.out.println(ave);
	}

}
