package Basic;

public class ReverseNumber {
public static void main(String[] args) {
	int n =23597;
	int sum =0;
	int rev = 0;
	while(n>0) {
		rev = n%10;
		
		n=n/10;
		sum = sum*10+rev;
	}
	
	System.out.println(sum);
}
}
