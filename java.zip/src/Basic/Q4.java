package Basic;

public class Q4 {

	public static void main(String[] args) {
		int n= 56;
		int m=45;
		System.out.println(n+m);
		System.out.println(n-m);
		System.out.println(n*m);
		System.out.println(n%m);
		System.out.println(n/m);
		
	}

}
