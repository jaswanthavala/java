package Basic;
import java.util.Scanner;
public class Q6 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		double radius=sc.nextDouble();
		sc.close();
		double area =Math.PI*radius*radius;
		System.out.println(area);
	}

}
