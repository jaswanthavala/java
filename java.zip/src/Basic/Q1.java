package Basic;

public class Q1 {
public static void main(String[] args) {
	int i=10;
	int j=20;
	System.out.println(i+j);
}
}
