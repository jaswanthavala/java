package Basic;

import java.util.Scanner;

public class PrimeNumbers {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	int n = s.nextInt();
	s.close();
	int count=0;                                               
	if(n>1) {
	
	for(int i=1 ;i<=n;i++) {
		if(n%i==0) {
			count++;
		}
	}
	if(count==2) {
		System.out.println(n +" is a prime");
	}
	else {
		System.out.println(n +"is not a prime");
	}
	}
}
}
