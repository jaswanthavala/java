package Strings;

import java.util.Scanner;

public class FrequenceOfCharacter {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	String a =s.nextLine();
	s.close();
	 char b[] =a.toCharArray();
	int count=0;
	for(int i=0;i<a.length();i++) {
		count =1;
		if(b[i]!='\0') {
		for(int j =i+1;j<a.length();j++) {
			if(b[i]==b[j]) {
				count++;
				b[j]='\0';
			}
		}
		System.out.println(b[i]+" "+ count);
		}
	}
}
}


