package Strings;

public class Duplicate {
public static void main(String[] args) {
	String s = "hi this is jaswanth hi this is  avala";
	int count=0;
	String w[] = s.split(" ");
	for(int i=0;i<w.length;i++) {
		count =1;
		 if (!w[i].equals("0")) {
		for(int j=i+1;j<w.length;j++) {
			if(w[i].equals(w[j])) {
				count++;
				w[j]="0";
			}
		}
		if(count>1) {
			System.out.println(w[i]);
		}
		 }
	}
}
}
