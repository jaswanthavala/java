package Strings;

import java.util.Scanner;

public class Punctutions {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter the string :");
	String s1 =s.nextLine();
	s.close();
	int count=0;
	for(int i=0;i<s1.length();i++) {
		if(s1.charAt(i)=='~'||s1.charAt(i)=='!'||s1.charAt(i)=='@'||s1.charAt(i)=='#'||s1.charAt(i)=='$'||s1.charAt(i)=='%'||s1.charAt(i)=='^'||s1.charAt(i)=='?') {
			count++;
		}
	}
	System.out.println(count);
}
}
