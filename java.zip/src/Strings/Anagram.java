package Strings;

import java.util.Arrays;
import java.util.Scanner;

public class Anagram {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("enter a string :");
	System.out.println("enter b string :");
	String a= s.nextLine();
	String b = s.nextLine();
	s.close();
	if(a.length()!=b.length()) {
		System.out.println("it is not a anagram");
		
	}
	char ch[] =a.toCharArray();
	char ch1[]=b.toCharArray();
	Arrays.sort(ch);
	Arrays.sort(ch1);
	if(Arrays.equals(ch, ch1)) {
		System.out.println("both are anagram");
	}
}
}
