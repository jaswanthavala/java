package Strings;

public class COUNT {
public static void main(String[] args) {
	String s = "hello jaswanth";
	System.out.println(s.length());
}
}
