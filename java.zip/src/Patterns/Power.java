package Patterns;

import java.util.Scanner;

public class Power {
public static double powe(int x ,int y) {
	return Math.pow(x, y);
}
public static void main(String[] args){
	Scanner s = new Scanner(System.in);
	int x = s.nextInt();
	int y = s.nextInt();
	double z = powe(x,y);
	System.out.println(z);
	s.close();
}
}
