package Patterns;

import java.util.Scanner;

public class Fabonnaic {
public static void  fab(int n) {
	int a=1;
	int m=2;
	for(int i=1;i<=n;i++) {
	int x=a+m;
System.out.println(x);
	a=m;
	m=x;
	}
	//return a;
}
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	int n =s.nextInt();
fab(n);
	
	s.close();
}
}
