package Patterns;

import java.util.Scanner;

public class Average {
	public static int ave(int a,int b,int c) {
		int Ave = (a+b+c)/3;
		return Ave;
	}
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	int a = s.nextInt();
	int b = s.nextInt();
	int c =s.nextInt();
	int Ave=ave(a,b,c);
	System.out.println(Ave);
	s.close();
}
}
