package Patterns;

import java.util.Scanner;

public class circumferenceofacircle {
public static float cricle(float r) {
	float  pi = 3.14f;
	r= r*r;
float cum = 2*pi*r;
return cum;
}
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	float r=s.nextFloat();
	float  b = cricle(r);
	System.out.println(b);
	s.close();
}
}
