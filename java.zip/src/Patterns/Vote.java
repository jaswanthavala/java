package Patterns;

import java.util.Scanner;

public class Vote {
public static String age(int n) {
	if(n>=18) {
		return "he can vote"; 
	}
	else {
		return "he cannot vote";
	}
	
}
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	int n =s.nextInt();
	String a = age(n);
	System.out.println(a);
	s.close();
}
}
