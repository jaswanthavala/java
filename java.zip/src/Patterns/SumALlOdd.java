package Patterns;

import java.util.Scanner;

public class SumALlOdd {
	public static int fun(int n) {
		int sum =0;
		for(int i=1;i<=n;i++) {
			if(i%2!=0) {
				sum = sum+n;
			}
		}
		return sum;
	}
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	int n =s.nextInt();
	int sum = fun(n);
	System.out.println(sum);
	s.close();
}
}
