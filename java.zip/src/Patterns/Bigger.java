package Patterns;

import java.util.Scanner;

public class Bigger {
public static int big(int a,int b)
{
	if(a>b) {
	return a;
	}
	else {
		return b ;
	}
}
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	int a = s.nextInt();
	int b =s.nextInt();
	int bigger = big(a,b);
	System.out.println(bigger +" is bigger");
	s.close();
}
}
