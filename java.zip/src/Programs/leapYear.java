package Programs;
import java.util.Scanner;
public class leapYear {
 public static void main(String []args) {
	 Scanner sc = new Scanner(System.in);
	 int n= sc.nextInt();
	 sc.close();
	 if(n%4==0&&n%100!=0||n%400==0) {
		 System.out.println("leap year");
	 }
	 else {
		 System.out.println("common year");
	 }
 }
}
