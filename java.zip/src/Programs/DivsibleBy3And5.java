package Programs;
import java.util.Scanner;
public class DivsibleBy3And5 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n =s.nextInt();
		s.close();
		if(n%3==0&&n%5==0) {
			System.out.println("it is divisble by both 3 and 5");
		}
		else {
			System.out.println("it is not divisble by both 3 and 5");
		}

	}

}
