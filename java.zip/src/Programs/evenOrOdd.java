package Programs;
import java.util.Scanner;
public class evenOrOdd {
  public static void main(String []args) {
	  Scanner sc = new Scanner(System.in);
	  int m=sc.nextInt();
		  if(m%2==0) {
			  System.out.println(m+" number is a even");
		  }
		  else {
			  System.out.println(m+" number is a odd");
		  }
		  sc.close();

	  }
  }

