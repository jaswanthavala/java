package Programs;

public class whilel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int j=0;
      while(j<=10) {
    	  System.out.println(j);
    	  j=j+2;
      }
      
	}

}
