package Programs;

import java.util.Scanner;
public class marks {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		sc.close();
		if(n<=35) {
			System.out.println("fail");
		}
		else if(n>=35&&n<=50) {
			System.out.println("Grade D");
		}
		else if(n>=50&&n<=75) {
			System.out.println("Grade C");
		}
		else if(n>=75&&n<=85) {
			System.out.println("Grade B");
		}
		else if(n>=85&&n<=100) {
			System.out.println("Grade A");
		}
		else {
			System.out.println("invalid");
		}
	}

}
