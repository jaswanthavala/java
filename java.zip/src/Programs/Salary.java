package Programs;

import java.util.Scanner;

public class Salary {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	int n =s.nextInt();
	s.close();
	if(n>10000) {
		n=n+2000;
		System.out.println(n);
	}
	else {
		n=n+1000;
		System.out.println(n);
	}
}
}
