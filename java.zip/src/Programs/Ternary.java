package Programs;

public class Ternary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=89;
int b=101;
int max=(a>b)?a:b;
System.out.println(max);
	}

}
