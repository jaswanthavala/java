package Calculate;

import java.util.Scanner;

public class ATM {
	 public static void main(String[] args) {
	        int balance =100000;

	        Scanner sc = new Scanner(System.in);
	        while (true) { 
	            System.out.println("choose 1 for withdraw");
	            System.out.println("choose 2 for deposit");
	            System.out.println("choose 3 for checkBalance");
	            System.out.println("choose 4 for exit");
	            int choice =sc.nextInt();
	            switch(choice){
	            case 1 :
	            
	            System.out.println("enter money to withdraw");
	            int withdraw = sc.nextInt();
	            if(balance >=withdraw) {
                 balance = balance -withdraw;
	            	System.out.println("take your amount");
	            }
	            else{
	            System.out.println("insufficent balance ");
	            }
	            System.out.println();
	            break;
	            case 2:
	            	System.out.println("enter your depoist amount");
	            	int depoist = sc.nextInt();
	            	sc.close();
	            	balance = balance +depoist;
	            	System.out.println("your amount is sucessfully credited");
	            	System.out.println();
	            	sc.close();
	            	break;
	            case 3:
	            	System.out.println("balance :"+ balance);
	            	System.out.println();
	            	break;
	            case 4:
	            	System.out.println("exit");
	            	break;
	            	
	            	default :
	            		System.out.println("invalid choice ");
	            		System.out.println();
	            		break;
	        }
	        }
	}
}
