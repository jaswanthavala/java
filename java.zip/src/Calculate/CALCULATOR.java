package Calculate;

import java.util.Scanner;

public class CALCULATOR {

	public static void main(String[] args) {
		int ans =0;
		Scanner s = new Scanner(System.in);
		System.out.println("enter the two numbers :");
		int n1 = s.nextInt();
		int n2 = s.nextInt();
		System.out.println("enter the operator :");
	while(true) {	
	char op =s.next().trim().charAt(0);
if(op=='+'||op=='-'||op=='*'||op=='/'||op=='%') {
	if(op=='+') {
		ans = n1+n2;
	}
	if(op=='-') {
		ans = n1-n2;
	}
	if(op=='*') {
		ans =n1*n2;
	}
	if(op=='/') {
		if(n2!=0) {
			ans =n1/n2;
		}
		
	}
	if(op=='%') {
		ans = n1%n2;
	}
	else if(op=='x'||op=='X'){
		break;
	}
	
}
	else		
	{
		System.out.println("invalid operator");
	}

System.out.println(ans + " is the answer");
	
	}
	s.close();
}
}
