package Stringpdf;

public class Q5 {

	public static void main(String[] args) {
		String s ="jaswanth";
		String s1=s.replace('a', 'e');
		System.out.println(s1);
	}

}
