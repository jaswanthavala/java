package Stringpdf;

public class Q1 {

	public static void main(String[] args) {
		String s  ="jaswanth";
		for(int i=0;i<s.length();i++) {
			char ch = s.charAt(i);
			System.out.println(ch);
		}

	}

}
