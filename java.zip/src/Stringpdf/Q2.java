package Stringpdf;

public class Q2 {

	public static void main(String[] args) {
		String s = "hello world";
		int s1=s.length();
		System.out.println(s1);
		for(int i=s.length()-1;i>=0;i--) {
			System.out.print(s.charAt(i));
			
		}
		
	}

}
