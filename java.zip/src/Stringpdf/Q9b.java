package Stringpdf;

public class Q9b {

	public static void main(String[] args) {
		StringBuilder s =new StringBuilder("this is mss company");
		s.reverse();
		System.out.println(s);
	

	}

}
