
package Stringpdf;

import java.util.Arrays;
import java.util.Scanner;

public class Occurances {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter a String name :");
	String a = (String) s.next();
	int count =0;
	
	int i=0;
	
	for( i=0;i<=a.length()-1;i++) {
		for(int j =i;j<=a.length()-1;j++) {
			if(a.charAt(i)==a.charAt(j)) {
				count++;
				System.out.println(a.charAt(i)+" "+count);
			}
		}
	}
}
}
