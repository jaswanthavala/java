package Stringpdf;

import java.util.StringTokenizer;

public class Q19 {

	public static void main(String[] args) {
		StringTokenizer s =new StringTokenizer("miracle software system");
	while(s.hasMoreElements()) {
		String s1=s.nextToken();
		for(int i=s1.length()-1;i>=0;i--) {
			System.out.print(s1.charAt(i));
		}
		System.out.println("");
	}
	}

}
