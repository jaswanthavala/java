package Stringpdf;

public class Q12 {

	public static void main(String[] args) {
		int vowles=0;
		int consonants =0;
		String s="This is a itg block";
		 s= s.toLowerCase();
	 for(int i=0;i<s.length();i++) {
		 if(s.charAt(i)=='a'||s.charAt(i)=='e'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u') {
			 vowles++;
		 }
		 else if(s.charAt(i)>='a'&&s.charAt(i)<'z') {
			 consonants++;
			 
		 }
//		 System.out.println(vowles);
//		 System.out.println(consonants);
	 }
	 System.out.println(vowles);
	 System.out.println(consonants);

	}

}
