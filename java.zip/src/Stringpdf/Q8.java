package Stringpdf;

public class Q8 {

	public static void main(String[] args) {
	String s="javatpoint";
	int count=0;
	for(int i=0;i<s.length();i++) {
		count++;
	}
System.out.println(count);
	}

}
