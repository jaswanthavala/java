package Stringpdf;

public class Q7 {

	public static void main(String[] args) {
	String s=new String("avala");
	String s1="jaswanth";
	String s2=new String("jaswanth");
	String s3="avala";
	System.out.println(s.equals(s1));
	System.out.println(s1.equals(s2));
	System.out.println(s2.equals(s3));
	System.out.println(s3.equals(s));
	System.out.println(s.equals(s2));

	}

}
