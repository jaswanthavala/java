package Stringpdf;

import java.util.Arrays;

public class Q9 {

	public static void main(String[] args) {
		String s ="education";
		char c[] = s.toCharArray();
		Arrays.sort(c);
		 String sorted= new String(c);
		 System.out.println(sorted);
	}

}
