package Stringpdf;

public class Q11 {

	public static void main(String[] args) {
		String arr[]= {"jaswanth","vijay","arjun"};
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}

	}

}
