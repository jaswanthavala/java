package Stringpdf;

public class Q10 {

	public static void main(String[] args) {
		String s ="@ssSAD32424?";
		 String s1=s.replaceAll("[^a-zA-Z]", " ");
System.out.println(s1);
	}

}
