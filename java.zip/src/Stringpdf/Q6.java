package Stringpdf;

public class Q6 {

	public static void main(String[] args) {
		String s1="miracle software system";
		String s="";
		s1=s1+" ";
		for(int i=0;i<s1.length();i++) {
			char ch = s1.charAt(i);
			if(ch!=' ') {
			s=s+ch;
			s= s.substring(0,1).toUpperCase() +s.substring(1);
			}
			else {
				System.out.println(s);
				s="";
			}
		}
	}

}
