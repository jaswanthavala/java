package Array;

import java.util.Scanner;

public class SumOfNPalinadrome {

	public static void main(String[] args) {
Scanner s = new Scanner(System.in);
int n = s.nextInt();
s.close();
int count=0;
int sum1=0;
for(int i =1;i<=n;i++) {
	int temp =i;
	int sum =0;
	int k =i;
	while(temp>0) {
		int r =temp%10;
		sum = sum*10+r;
		temp=temp/10;
		
	}
	if(k==sum)
	{
		count++;
		sum1 =sum1+k;

	}

}
System.out.println(count);
System.out.println(sum1);
	}

}
