package Array;
import java.util.Scanner;

public class arraya {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
         int n = s.nextInt();
         int sum = 0;
  int temp=n;
  while(n>0) {
	int  r = n%10;
	  sum = (sum*10)+r;
	  n=n/10;
  }
	if(temp==sum) {  
		System.out.println("yes it is a palinadrome");
	}
	else {
		System.out.println("No it is not a  palinadrome");
	}
  s.close();
    }
}