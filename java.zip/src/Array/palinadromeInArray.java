package Array;

public class palinadromeInArray {
public static void main(String[] args) {
	int arr[] = {545,66,334,56};
	int count=0;
	for(int i=0;i<arr.length;i++) {
		int sum =0;
		int temp = arr[i];
		int n = temp;
		while(n>0) {
			int r = n%10;
			sum = sum*10+r;
			n=n/10;
		}
		if(temp==sum) {
			count++;
		}
	}
	System.out.println(count);
}
}
