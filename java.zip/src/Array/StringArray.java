package Array;

public class StringArray {
public static void main(String[] args) {
	String s []= {"hi","java","name"};
	String s1[]= {"hello","language","name"};
	for(int i =0;i<s.length;i++) {
		for(int j =0;j<s1.length;j++) {
		
			if(s[i].equals(s1[j])) {
				System.out.println(s[i]);
			}
		}
	}
	
}
}
