package Array;
interface a{
	void msg();
}
abstract class b implements a{
	 abstract void call();
	static void msgs() {
		System.out.println("message me in whatsApp");
	}
}
public  class Multilevel extends b  {
	public void msg() {
		System.out.println("sent a msg");
	}
	 void call() {
		 System.out.println("call to this number");
		 
	 }
public static void main(String[] args) {
	Multilevel m = new Multilevel();
	m.call();
	m.msg();
	b.msgs();
	
}
}
