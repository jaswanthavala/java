package Array;

public class Recurssion {
	
	public static void main(String[] args) {
		Recurssion.fun(2);
	}
		static void fun(int n) {
			System.out.println(n);
			if(n>0) {
				fun(n-1);
			}
			System.out.println(n);
		}
	
}
