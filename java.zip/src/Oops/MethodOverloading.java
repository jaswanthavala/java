package Oops;
class method{
	static int add(int a ,int b) {
		return a+b;
	}
	static int add(int a ,int b ,int c) {
		return a+b+c;
		}
	static int add(int a,int b ,int c ,int d) {
		return a+b+c+d;
	}
	
}
public class MethodOverloading {

	public static void main(String[] args) {
		System.out.println(method.add(4234, 43523));
        System.out.println(method.add(42425, 53422, 64342));
        System.out.println(method.add(34241, 532412, 42212, 53412));
	}

}
