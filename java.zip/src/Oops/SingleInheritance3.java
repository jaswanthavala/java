package Oops;
class A{
	static int add(int c ,int d) {
		return c+d;
	}
}
public class SingleInheritance3 extends A {

	public static void main(String[] args) {
	
		System.out.println(A.add(34253, 54654));
	

	}

}
