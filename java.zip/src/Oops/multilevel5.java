package Oops;
class vechile5{
	void run() {
		System.out.println("vechile is running");
	}
}
class  bike11 extends vechile5{
	void start() {
		System.out.println("bikee is running");
	}
}
class car11 extends bike11{
	void accelrate() {
		System.out.println("car is rrunning");
	}
}
public class multilevel5 {

	public static void main(String[] args) {
		car11 c = new car11();
		c.accelrate();c.run();c.start();

	}

}
