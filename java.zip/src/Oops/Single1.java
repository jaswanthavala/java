package Oops;
class A23{
	void run() {
		System.out.println("he is running");
	}
}
class B23 extends A23{
	void call() {
		System.out.println("he is calling ");
	}
}
public class Single1 {

	public static void main(String[] args) {
		B23 b = new B23();
		b.call();
		b.run();
	}

}
