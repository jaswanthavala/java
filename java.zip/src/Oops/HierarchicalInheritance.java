package Oops;
class Animal1{
	void cat() {
		System.out.println("meowww.....");
	}
}
class bird extends Animal1{
	void parrot() {
		System.out.println("parrot is in green colour");
	}
}
class bike2 extends Animal1{
	void bike1 () {
		System.out.println("please start the bike");
	}
}
class song extends bird {
	void sing() {
		System.out.println("i am singing");
	}
}
public class HierarchicalInheritance {

	public static void main(String[] args) {
		bike2 b =new bike2();
		b.bike1();
		b.cat();
		song s =new song();
		s.sing();
		s.parrot();
		
		
	}

}
