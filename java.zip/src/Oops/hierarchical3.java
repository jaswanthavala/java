package Oops;
class animal
{
	void eat() {
		System.out.println("eating....");
	}
}
class rabbit extends animal
{
	void walk() {
		System.out.println("walking......");
	}
}
class lion extends animal
{
	void see() {
		System.out.println("seeing.......");
	}
}
public class hierarchical3 {
public static void main(String[] args) {
	lion l = new lion();
	l.see();l.eat();
	
}
}
