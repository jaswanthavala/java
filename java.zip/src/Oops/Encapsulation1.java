package Oops;
class room{
	private int rollno;
	private String name;
	private String sec;
public int getRollno() {
	return rollno;
}
public void setRollno(int rollno) {
	this.rollno = rollno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getSec() {
	return sec;
}
public void setSec(String sec) {
	this.sec = sec;
}

}
public class Encapsulation1 {

	public static void main(String[] args) {
room r =new room();
r.setName("jaswanth");
r.setRollno(120);
r.setSec("B");
System.out.print(r.getName()+" ");
System.out.print(r.getRollno()+" ");
System.out.print(r.getSec());
	}

}
