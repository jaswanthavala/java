package Oops;
//in this example, Shape is the abstract class, and its implementation is 
//provided by the Rectangle and Circle classes.
//
//Mostly, we don't know about the implementation class (which is hidden to the end user),
//and an object of the implementation class is provided by the factory method.
abstract class shape1{
	abstract void draw();
}
class reactangle extends shape1{
	void draw(){
		System.out.println("draw a reactangle");
	}
}
class circle extends shape1{
	void draw() {
		System.out.println("draw a cricle");
	}
}
public class Abtraction1 {

	public static void main(String[] args) {
		shape1 s ;
		s=new reactangle();
		s.draw();
		s=new circle();
		s.draw();
		
	}

}
