package Oops;
class Single{
	void add() {
		System.out.println(343543+567432);
	}
	void sub() {
		System.out.println(76542-43565);
	}
}
class subclass extends Single{
	void  multi() {
		System.out.println(2324*45);
	}
}
public class SingleInheritance {

	public static void main(String[] args) {
		subclass s=new subclass();
		s.add();
		s.sub();
		s.multi();
		

	}

}
