package Oops;
class vechile{
	void run () {
		System.out.println("starting a bike");
	}
}
class car extends vechile{
	void run() {
		System.out.println("this is a swift car");
	}
}
class biike extends vechile{
	void run() {
		System.out.println("The tvs radier is the new version");
	}
}
public class MethodOverriding {

	public static void main(String[] args) {
		
		vechile v1 ,v2,v3;
		v1=new car();
		v2=new biike();
		v3=new vechile();
		v1.run();
		v2.run();
		v3.run();
		

	}

}
