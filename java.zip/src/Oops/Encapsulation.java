package Oops;
class Student{
	private int id ;
	private String name;
public int getId(){
	id =101;
	return id;
	
	
}
public String getName() {
	name ="arjun";
	return name;
}
}
public class Encapsulation {

	public static void main(String[] args) {
	Student s = new Student();
	s.getId();
	s.getName();
	System.out.println(s.getId());
	System.out.println(s.getName());

	}

}
