package Oops;
class x{
	int add(int a ,int b) {
		return a+b;
	}
}
class y extends x{
	int sub(int a,int b) {
		return a-b;
	}
}
class z extends x {
	int multi(int a,int b) {
		return a*b;
	}
}
class w extends y{
	int div(int a,int b) {
		return a/b;
	}
}
public class Hierarchical {

	public static void main(String[] args) {
		w s = new w();
		System.out.println(s.sub(24242, 533));
		System.out.println(s.div(423423, 3));

	}

}
