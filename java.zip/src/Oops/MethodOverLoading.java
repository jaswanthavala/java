package Oops;
class math{
	static int add(int a,int b) {
		return a+b;
	}
	static int add(int a,int b, int c)
	{
		return a+b+c;
	}
}
public class MethodOverLoading {

	public static void main(String[] args) {
		System.out.println(math.add(244353, 45232));
		System.out.println(math.add(424325, 423154,454323));

	}

}
