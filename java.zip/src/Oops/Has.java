package Oops;
class phone{
	void cam() {
		System.out.println("click  the pics");
	}
}
class game11{
	void play() {
		System.out.println("playing games in phone");
	}
}

public class Has {
	phone p = new phone();
	game11  g = new game11();
	void  call() {
		System.out.println("calling to others");
	}

	public static void main(String[] args) {
		Has h =new Has();
		h.g.play();
		h.p.cam();
		h.call();
	}

}
