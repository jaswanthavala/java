package Oops;
abstract class  Abstract {
	abstract void sub();
	}
	class sec extends Abstract{
		void sub() {
			System.out.println("class teacher sub is maths");
		}
	}
		public class  Abstraction{
		public static void main(String[] args) {
			Abstract a = new sec();
			a.sub();

			}

		}

