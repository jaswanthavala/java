package Oops;
//In this example, the Drawable interface has only one method.
//Its implementation is provided by Rectangle and Circle classes.
//In a real scenario, an interface is defined by someone 
//else, but its implementation is provided by different implementation providers. 
//Moreover, it is used by someone else. The implementation part is hidden by the user who uses the interface.
interface Drawable{
	void draw();
}
class reactangle2 implements Drawable{
	public void draw() {
		System.out.println("draw a reactangle");
	}
}
class circle2 implements Drawable{
	public void draw() {
		System.out.println("draw a circle");
	}
}
public class Interface {

	public static void main(String[] args) {
		Drawable d = new circle2();
d.draw();
	}

}
