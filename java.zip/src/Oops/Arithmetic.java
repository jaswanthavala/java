package Oops;

import java.util.Scanner;

class maths{
	int add(int a,int b ) {
		return a+b;
	}
}

public class Arithmetic extends maths  {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int a =s.nextInt();
		int b =s.nextInt();
		s.close();
		System.out.println("my super class is ");
		Arithmetic c = new Arithmetic();
		c.add(a, b);
		System.out.println(c.add(a, b));
		
	}

}
