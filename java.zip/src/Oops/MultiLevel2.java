package Oops;
class game{
	void cric() {
		System.out.println("virat is a one down batter");
	}
}
class kabbadi extends game{
	void kab() {
		System.out.println("rahul is a raider");
	}
}
class football extends kabbadi{
	void foot() {
		System.out.println("messi is the great football player");
	}
}
public class MultiLevel2  {

	public static void main(String[] args) {
		football  m = new football();
		m.cric();
		m.kab();
		m.foot();

	}

}
