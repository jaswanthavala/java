package Oops;
class Data{
	static int add(int a,int b) {
		return a+b;
	}
	static float add(float a,float c) {
		return a+c;
	}
}
public class ByChangingDataTypes {
public static void main(String[] args) {
	System.out.println(Data.add(34235534, 6743422));
	System.out.println(Data.add(35383f, 4325411f));
}
}
