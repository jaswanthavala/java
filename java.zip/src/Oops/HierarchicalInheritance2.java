package Oops;
class A1{
	void message() {
		System.out.println("oops means Object-Oriented Programming system");
	}
}
class B1 extends A1{
	void message2() {
		System.out.println("java is a programming lang");
	}
}
class C1 extends A1{
	void message3() {
		System.out.println("five types of inheritance");
	}
}
public class HierarchicalInheritance2 {

	public static void main(String[] args) {
		C1 m = new C1();
	    B1 n=new B1();
		m.message3();
		m.message();
		n.message2();
		
		
	}

}
