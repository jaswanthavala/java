package Oops;
class student{
	int id;
	String name;
	int rollno;
	student(int id,String name,int rollno){
		this.id=id;
		this.name=name;
		this.rollno=rollno;
	}
	void display() {
		System.out.println(id+" "+name+" "+rollno);
	}
	
}
public class This {
public static void main(String[] args) {
	student s1=new student(1,"jay",136531);
	student s2=new student(2,"arjun",123472);
	s1.display();
	s2.display();
	
}
}
