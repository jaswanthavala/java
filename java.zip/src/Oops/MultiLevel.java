package Oops;
class Animal{
	void dog() {
		System.out.println("barking");
	}
	void cat() {
		System.out.println("meow....");
	}
}
class bike extends Animal{
	void bike1() { 
		System.out.println("start the bike");
	}
}
public class MultiLevel  extends bike{

	public static void main(String[] args) {
		MultiLevel m=new MultiLevel();
		m.bike1();
		m.cat();
		m.dog();
	}

}
