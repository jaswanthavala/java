package Oops;
class has{
	void show() {
		System.out.println("three shows per day");
	}
}
class Has_A {
	has h = new has();
	void runs() {
		System.out.println("he runs two times in a day");
	}
	public static void main(String[] args) {
		Has_A a = new Has_A();
		a.h.show();
		a.runs();

	}

}
