package Oops;
class Demo{
	void add(){
		System.out.println(2345+53435);
	}
	void cric() {
		System.out.println("virat is a cricketer");
	}
	
}
public class SingleInheritance2 extends Demo {

	public static void main(String[] args) {
		SingleInheritance2 si = new SingleInheritance2();
		si.add();
		si.cric();

	}

}
