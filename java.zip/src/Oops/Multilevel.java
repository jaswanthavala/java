package Oops;
class A12{
	int add (int a ,int b) {
		return a+b;
	}
}
class B12 extends A12{
	int sub(int a,int b) {
		return a-b;
	}
}
class C12 extends B12{
	int div(int a,int b) {
		return a/b;
	}
}
public class Multilevel extends C12 {

	public static void main(String[] args) {
		Multilevel m=new Multilevel();
		System.out.println(m.add(322423, 632131));
		System.out.println(m.div(421235,5));
		System.out.println(m.sub(2324352, 53434));
	}

}
