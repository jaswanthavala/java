package Oops;
abstract class car2{
	car2(){
		System.out.println("This is a swift car");
	}
	//abstract method 
	abstract void run();
	//non abstract method
	void changegare(){
		System.out.println("Car is running in 3rd geaer");
	}
}
class benz extends car2{
	void run() {
		System.out.println("This benz is new model");
	}
	void changegare() {
		System.out.println("Benz is runing in 5th geaer");
	}
}

public class Abstraction2 {

	public static void main(String[] args) {
		car2 b = new benz();
		b.changegare();
		b.run();
	
	}

}
