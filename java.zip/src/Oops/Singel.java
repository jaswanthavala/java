package Oops;
class Demo1{
	static int add( int a, int b) {
		return a+b;
	}
	 static int sub(int a,int b) {
		return a-b;
	}
}
class Demo2 extends Demo1{
	static int multi(int a ,int b) {
		return a*b;
	}
}
public class Singel {

	public static void main(String[] args) {
		Demo2 d =new Demo2();
		System.out.println(d.add(23423, 53432));
		System.out.println(d.sub(234234, 42242));
		System.out.println(d.multi(2344, 234));
	}

}
