package Oops;
class shape{
	void draw() {
		System.out.println("drawing..");
	}
}
	class  rectangle extends shape{
		void draw() {
			System.out.println("drawing a rectangle");
		}
		
	}
	class square extends rectangle{
		void draw() {
			System.out.println("drawing a square");
		}
	}
	class triangle extends square {
		void draw() {
			System.out.println("drawing a triangle");
		}
	}


public class MethodOverridding {

	public static void main(String[] args) {
		triangle s1= new triangle();
		s1.draw();
//		s2.draw();
//		s3.draw();
//		s4.draw();
		
	

	}

}
