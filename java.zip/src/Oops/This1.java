package Oops;
class cse{
	int id ;
	String name;
	String email;
	cse(int id,String name,String email){
		this.id=id;
		this.name=name;
		this.email=email;
	}
		void display() {
			System.out.println(id+" "+name+" "+ email);
		}
	}

public class This1 {

	public static void main(String[] args) {
		cse s= new cse(101 ,"jaddu","jaddu009@gmail.com");
		cse s1= new cse(102 ,"jassu","jassu009@gmail.com");
		cse s2= new cse(103 ,"arjun","arjun009@gmail.com");
		s.display();
		s1.display();
		s2.display();
	}

}
