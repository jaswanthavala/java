package Oops1;
interface demo1{
	void run();
}
interface sample1{
	void start();
}
interface test1{
	void end();
}
 class Interface1 implements demo1,sample1,test1{
public void run(){
	System.out.println("vechile get started ");
}
public void start() {
	System.out.println("vechile get runs");
}
public void end() {
	System.out.println("vechile will stopped");
}
	public static void main(String[] args) {
		Interface1 i = new Interface1();
i.run();
i.start();
i.end();
	}

}
