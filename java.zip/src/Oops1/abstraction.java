package Oops1;
abstract class Main{
	abstract void call();
	void onlinecall() {
		System.out.println("calling through the online");
	}
}
class phone extends Main{
	void call() {
		System.out.println("calling to someone");
	}
	void onlinecall() {
		System.out.println("calling to someone in online");
	
	super.onlinecall();
	}
}
public class abstraction {
public static void main(String[] args) {
	Main m = new phone();
	m.call();
	m.onlinecall();
}
}
