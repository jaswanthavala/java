package Oops1;
interface a{
	void run();
}
interface b {
	void speed();
}

public class MultipleInheritanceInInterace  implements a,b{
	public void run() {
		System.out.println("it runs upto 150kmph");
	}
	public void speed() {
		System.out.println("the is 60kmph now");
	}

	public static void main(String[] args) {
		MultipleInheritanceInInterace d = new MultipleInheritanceInInterace ();
d.run();
d.speed();
	}

}
