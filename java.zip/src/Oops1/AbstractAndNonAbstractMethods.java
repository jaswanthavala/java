package Oops1;
abstract class message{
	abstract void send();
	void recevie()
	{
		System.out.println("you have a unreaden message ");
	}
}
class recevier extends message{
	void send() {
		System.out.println("new message by sender");
	}
}
class sender extends message{ 
	void send() {
		System.out.println("your message is delivered");
	}
}
public class AbstractAndNonAbstractMethods {

	public static void main(String[] args) {
		message m =  new sender();
		m.send();
		//m.recevie();
		m =new recevier();
		m.send();
		

	}

}
