package Oops1;
class Demo{
	 int add(int a ,int b) {
		return a+b;
	}
	 int add(int a,int b,int c) {
		 return a+b+c;
	 }
	 double  add(double a,int b) {
		 return a*b;
	 }
	 double add(int a,double b) {
		 return a/b;
	 }
}
public class MethodOverLoading {
public static void main(String[] args) {
	Demo d = new Demo();
	System.out.println(d.add(42424, 04242));
	System.out.println(d.add(3232, 042342, 024242));
	System.out.println(d.add(1233.56, 3324));
	System.out.println(d.add(34242, 023223.65));
	
}
}
