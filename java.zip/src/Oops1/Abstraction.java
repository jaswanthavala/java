package Oops1;
abstract class bank{
	abstract void enterpin();
}
class Sbi  extends bank{
	void enterpin() {
		System.out.println("enter sbi pin in sbi atm :");
	}
}
class atm extends bank{
	void enterpin(){
		System.out.println("enter pin of other bank :");
	}
}
public class Abstraction {

	public static void main(String[] args) {
	bank b = new atm();
	b.enterpin();
	}

}
