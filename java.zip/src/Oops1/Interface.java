package Oops1;
interface Atm{
	void pin();
}
abstract class withdraw implements Atm{ 
	  public void pin() {
		System.out.println("take your cash ");
	}
}
class pingentration implements Atm{
	public void pin() {
		System.out.println("change your pin");
	}
}
public class Interface {

	public static void main(String[] args) {
		Atm a = new pingentration();
		a.pin();
	}

}
