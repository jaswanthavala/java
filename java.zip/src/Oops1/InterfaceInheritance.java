package Oops1;
interface A{
	void show();
}
interface B extends  A{
	void match();
}

   class InterfaceInheritance implements B  {
		public void show() {
			System.out.println("it`s shows the functiontaility");
		}
		public void match() {
			System.out.println("matches");
		}
	public static void main(String[] args) {
		InterfaceInheritance n = new InterfaceInheritance();
		n.match();
		n.show();
	}

}
