package Oops1;
class demo 
{
 int add(int a,int b ) {
		return a+b;
	}
}
class test extends demo {
	int add(int a,int b ) {
		return a*b;
	}
}
class sample  extends demo{
	int add(int a,int b) {
		return a/b;
	}
}
public class MethodOverriding {

	public static void main(String[] args) {
		demo d =new sample();
		System.out.println(d.add(43243, 42423));
	}

}
