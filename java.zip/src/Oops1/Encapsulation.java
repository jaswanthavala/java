package Oops1;
class Student{
	private String name;
	private int rollno;
	private float marks;
	public String getName(){
		return name;
	}
	public void setName(String name) {
		this.name= name;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno=rollno;
	}
	public float getMarks() {
		return marks;
	}
	public void setMarks(float marks) {
		this.marks=marks;
	}
}
public class Encapsulation {

	public static void main(String[] args) {
		Student s =new Student();
		s.setMarks(87.8f);
s.setName("avala ");
s.setRollno(123);
System.out.print(s.getName()+" ");
System.out.print(s.getRollno()+" ");
System.out.print(s.getMarks()+" ");
	}

}
