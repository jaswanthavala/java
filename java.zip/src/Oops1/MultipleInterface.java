package Oops1;
interface A33{
	 void call();
}
interface B33 extends A33{
	void message();
}
 public class MultipleInterface implements A33,B33 {
	 public void call() {
			System.out.println("enter your phone number");
		}
	 public void message() {
		 System.out.println("send a message");
	 }
	 
public static void main(String[] args) {
	MultipleInterface m = new MultipleInterface ();
	m.call();
			m.message();
}
}
